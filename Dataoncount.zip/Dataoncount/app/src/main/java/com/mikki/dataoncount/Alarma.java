package com.mikki.dataoncount;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;

@SuppressWarnings("ALL")
public class Alarma
  extends BroadcastReceiver
{
  private static final int NOTIF_ALERTA_ID = 1;
  
  private void ActivaAlarma(Context paramContext, int paramInt, boolean paramBoolean)
  {
    int i;
    long l;
    PendingIntent localPendingIntent;
    try
    {
      Intent localIntent = new Intent(paramContext, Alarma.class);
      localIntent.putExtra("EsAutomatico", 1);
      localIntent.putExtra("Posicion", paramInt);
      localIntent.putExtra("Desde", "Reconf");
      localPendingIntent = PendingIntent.getBroadcast(paramContext, 0, localIntent, 0);
      i = 0;
      if (paramInt != 1) {

      }
      i = 30;
    }
    catch (Exception localException)
    {

      new Util().WriteLog(paramContext, "Error 244: " + localException.getMessage());
      return;
    }
    l = SystemClock.elapsedRealtime() + 1000 * (i * 60);
    ((AlarmManager)paramContext.getSystemService(Context.ALARM_SERVICE)).setRepeating(2, l, 1000 * (i * 60), localPendingIntent);
    String str = null;
    if (paramBoolean)
    {
      str = "";
      if (paramInt != 1) {

      }
      str = "Red móvil activa.";
    }
    for (;;)
    {
      new Util().WriteLog("--> " + str + " Frecuencia reconfigurada a: " + Integer.toString(i) + " min.");

      label209:
      if (paramInt == 2) {
        i=60;
      }
      if (paramInt != 3) {
        break;
      }
      i = 90;

      label230:
      if (paramInt == 2) {
        str = "Red wifi activa.";
      }
      if (paramInt == 3) {
        str = "Sin conexión de red.";
      }
    }
  }
  
  private void CompruebaContadores(SQLiteDatabase paramSQLiteDatabase, Context paramContext)
  {
    ArrayList localArrayList = new BDContadores().SeleccionaContadoresConNotificacion(paramSQLiteDatabase);
    Calendar localCalendar = Calendar.getInstance();
    ContadoresUtil localContadoresUtil = new ContadoresUtil();
    Double.valueOf(0.0D);
    Iterator localIterator = localArrayList.iterator();
    for (;;)
    {
      if (!localIterator.hasNext()) {
        return;
      }
      BDContadores localBDContadores = (BDContadores)localIterator.next();
      if ((localCalendar.getTimeInMillis() > Util.FormatoFecha(localBDContadores.fechaSiguienteAviso).getTimeInMillis()) && (localContadoresUtil.CalculaUnContador(localContadoresUtil.Desde(localBDContadores), localBDContadores, paramContext, paramSQLiteDatabase).doubleValue() > localBDContadores.mbNoti))
      {
        localBDContadores.Avisado(paramSQLiteDatabase, true, localContadoresUtil.CalculaSiguienteAviso(localBDContadores.tipo), localBDContadores.id);
        Notifica(paramContext, paramContext.getResources().getString(0), new StringBuilder(String.valueOf(paramContext.getResources().getString(2131165320))).append(" ").toString() + localContadoresUtil.DescripcionContadorCorta(localBDContadores, paramContext));
      }
    }
  }
  
  private void CompruebaDesviacion(Configuracion paramConfiguracion, SQLiteDatabase paramSQLiteDatabase, Context paramContext)
  {
    int i = Calendar.getInstance().get(5);
    if (i >= paramConfiguracion.diaFactura)
    {
      if (i - paramConfiguracion.diaFactura < 3) {}
      int j;
      for (j = 1;; j = 0)
      {
        Double localDouble = new Trafico().HayDesviacion(paramContext, paramSQLiteDatabase);
        if (localDouble.doubleValue() <= 0.0D) {
          break;
        }
        if ((j == 0) && (paramConfiguracion.avisado <= 0))
        {
          paramConfiguracion.Avisado(paramSQLiteDatabase, true);
          Notifica(paramContext, paramContext.getResources().getString(2131165318), new StringBuilder(String.valueOf(paramContext.getResources().getString(2131165319))).append(" ").toString() + Util.FormatoDecimal(localDouble));
        }
        return;
      }
    }
    if (paramConfiguracion.diaFactura - i >= 28) {}
    for (int j = 1;; j = 0) {
      break;
    }
    paramConfiguracion.Avisado(paramSQLiteDatabase, false);
  }
  
  private void DesactivaAlarma(Context paramContext)
  {
    try
    {
      PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, 0, new Intent(paramContext, Alarma.class), 0);
      ((AlarmManager)paramContext.getSystemService(Context.ALARM_SERVICE)).cancel(localPendingIntent);
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(paramContext, "Error 314: " + localException.getMessage());
    }
  }
  
  private void Notifica(Context paramContext, String paramString1, String paramString2)
  {
    NotificationManager localNotificationManager = (NotificationManager)paramContext.getSystemService(Context.NOTIFICATION_SERVICE);
    Notification localNotification = new Notification(17301642, paramContext.getResources().getString(2131165317), System.currentTimeMillis());
    //localNotification.setLatestEventInfo(paramContext, paramString1, paramString2, PendingIntent.getActivity(paramContext, 0, new Intent(paramContext, ConsumoDatosInternetActivity.class), 0));
    localNotification.flags = (0x10 | localNotification.flags);
    localNotificationManager.notify(1, localNotification);
  }
  
  private void ReconfiguraAlarma(Context paramContext, int paramInt, boolean paramBoolean)
  {
    ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkInfo localNetworkInfo = localConnectivityManager.getNetworkInfo(1);
    if (localConnectivityManager.getNetworkInfo(0).isConnected()) {
      if (paramInt != 1)
      {
        DesactivaAlarma(paramContext);
        ActivaAlarma(paramContext, 1, paramBoolean);
      }
    }
    do
    {
      do
      {

        if (!localNetworkInfo.isConnected()) {
          break;
        }
      } while (paramInt == 2);
      DesactivaAlarma(paramContext);
      ActivaAlarma(paramContext, 2, paramBoolean);

    } while (paramInt == 3);
    DesactivaAlarma(paramContext);
    ActivaAlarma(paramContext, 3, paramBoolean);
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    boolean bool = true;
    try
    {
      Bundle localBundle = paramIntent.getExtras();
      int i = localBundle.getInt("EsAutomatico", 0);
      String str = localBundle.getString("Desde");
      CDIBD localCDIBD = new CDIBD(paramContext, null, ConsumoDatosInternetActivity.versionBD);
      SQLiteDatabase localSQLiteDatabase = localCDIBD.getWritableDatabase();
      new Trafico().ConsultaYGuarda(paramContext, str, localSQLiteDatabase);
      Configuracion localConfiguracion = new Configuracion();
      localConfiguracion.CargaConfiguracion(localSQLiteDatabase, paramContext);
      if (localConfiguracion.notificaciones > 0)
      {
        CompruebaDesviacion(localConfiguracion, localSQLiteDatabase, paramContext);
        if (ConsumoDatosInternetActivity.app == "PRO") {
          CompruebaContadores(localSQLiteDatabase, paramContext);
        }
      }
      localCDIBD.CierraBD(localSQLiteDatabase);
      int j = 0;
      if (i > 0)
      {
        j = localBundle.getInt("Posicion", 1);
        if (localConfiguracion.guardaLog <= 0) {

        }
      }
      for (;;)
      {
        ReconfiguraAlarma(paramContext, j, bool);
        label153:
        bool = false;
      }
    }
    catch (Exception localException)
    {
      new Util().WriteLog("Error 15: " + localException.getMessage());
    }
  }
}

