package com.mikki.dataoncount;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class Aplicaciones
{
  public static final String Campos = " (id integer primary key autoincrement, fecha string, uid integer, appname string, movilRX long, movilTX long) ";
  public static final String TableName = "Aplicaciones";
  public static final int columnaName = 3;
  public static final int columnaRx = 4;
  public static final int columnaTx = 5;
  public static final int columnaUid = 2;
  public static final String sqlCreate = "CREATE TABLE Aplicaciones (id integer primary key autoincrement, fecha string, uid integer, appname string, movilRX long, movilTX long) ";
  public static final String sqlCreateIfNotExists = "CREATE TABLE if not exists Aplicaciones (id integer primary key autoincrement, fecha string, uid integer, appname string, movilRX long, movilTX long) ";
  public static final String sqlDeleteTable = "DROP TABLE IF EXISTS Aplicaciones";
  public String appname;
  public String fecha;
  public long movilRX;
  public long movilTX;
  public int uid;
  
  public void Inserta(SQLiteDatabase paramSQLiteDatabase, Context paramContext)
  {
    String str1 = "";
    String str2 = "";
    try
    {
      Calendar localCalendar = Calendar.getInstance();
      GregorianCalendar localGregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
      int i = Integer.parseInt(paramContext.getResources().getString(0));
      localGregorianCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 0, 0, 0);
      localGregorianCalendar.add(2, i * -1);
      str1 = "DELETE FROM Aplicaciones WHERE fecha < '" + Util.FormatoFecha(localGregorianCalendar) + "'";
      paramSQLiteDatabase.execSQL(str1);
      str2 = "INSERT INTO Aplicaciones (fecha, uid, appname, movilRX, movilTX) VALUES  (" + this.fecha + ", " + this.uid + ", '" + this.appname.replace("'", "_") + "', " + this.movilRX + ", " + this.movilTX + ")";
      paramSQLiteDatabase.execSQL(str2);
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog("Error 3344 (inserta aplicaciones): " + localException.getMessage() + " sqlIns: " + str2 + " sqlDel: " + str1);
    }
  }
  
  public ArrayList<Integer> SeleccionaAplicacionesEntreFechas(SQLiteDatabase paramSQLiteDatabase, Calendar paramCalendar1, Calendar paramCalendar2)
  {
    String[] arrayOfString = new String[2];
    arrayOfString[0] = Util.FormatoFecha(paramCalendar1);
    arrayOfString[1] = Util.FormatoFecha(paramCalendar2);
    Cursor localCursor = paramSQLiteDatabase.rawQuery(" SELECT distinct uid FROM Aplicaciones WHERE fecha>=? AND fecha<=? ORDER BY fecha", arrayOfString);
    ArrayList localArrayList = new ArrayList();
    if ((localCursor.getCount() > 1) && (localCursor.moveToFirst())) {
      localArrayList.add(Integer.valueOf(localCursor.getInt(0)));
    }
    for (;;)
    {
      if (!localCursor.moveToNext())
      {
        localCursor.close();
        return localArrayList;
      }
      localArrayList.add(Integer.valueOf(localCursor.getInt(0)));
    }
  }
  
  public Cursor SeleccionaDesdeDia(SQLiteDatabase paramSQLiteDatabase, Calendar paramCalendar)
  {
    GregorianCalendar localGregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    localGregorianCalendar.set(paramCalendar.get(1), paramCalendar.get(2), paramCalendar.get(5), 0, 0, 0);
    String[] arrayOfString = new String[1];
    arrayOfString[0] = Util.FormatoFecha(localGregorianCalendar);
    return paramSQLiteDatabase.rawQuery(" SELECT id, fecha, uid, appname, movilRX, movilTX FROM Aplicaciones WHERE fecha>? ORDER BY uid, fecha", arrayOfString);
  }
  
  public Cursor SeleccionaEntreFechas(SQLiteDatabase paramSQLiteDatabase, Calendar paramCalendar1, Calendar paramCalendar2)
  {
    String[] arrayOfString = new String[2];
    arrayOfString[0] = Util.FormatoFecha(paramCalendar1);
    arrayOfString[1] = Util.FormatoFecha(paramCalendar2);
    return paramSQLiteDatabase.rawQuery(" SELECT id, fecha, uid, appname, movilRX, movilTX FROM Aplicaciones WHERE fecha>=? AND fecha<=? ORDER BY uid, fecha", arrayOfString);
  }
  
  public Cursor SeleccionaEntreFechas(SQLiteDatabase paramSQLiteDatabase, Calendar paramCalendar1, Calendar paramCalendar2, Integer paramInteger)
  {
    String[] arrayOfString = new String[3];
    arrayOfString[0] = Util.FormatoFecha(paramCalendar1);
    arrayOfString[1] = Util.FormatoFecha(paramCalendar2);
    arrayOfString[2] = Integer.toString(paramInteger.intValue());
    return paramSQLiteDatabase.rawQuery(" SELECT id, fecha, uid, appname, movilRX, movilTX FROM Aplicaciones WHERE fecha>=? AND fecha<=? AND uid=? ORDER BY uid, fecha", arrayOfString);
  }
  
  public Cursor SeleccionaUnDia(SQLiteDatabase paramSQLiteDatabase, Calendar paramCalendar)
  {
    GregorianCalendar localGregorianCalendar1 = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    localGregorianCalendar1.set(paramCalendar.get(1), paramCalendar.get(2), paramCalendar.get(5), 0, 0, 0);
    GregorianCalendar localGregorianCalendar2 = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    localGregorianCalendar2.set(paramCalendar.get(1), paramCalendar.get(2), paramCalendar.get(5), 23, 59, 59);
    String[] arrayOfString = new String[2];
    arrayOfString[0] = Util.FormatoFecha(localGregorianCalendar1);
    arrayOfString[1] = Util.FormatoFecha(localGregorianCalendar2);
    return paramSQLiteDatabase.rawQuery(" SELECT id, fecha, uid, appname, movilRX, movilTX FROM Aplicaciones WHERE fecha>=? AND fecha<=? ORDER BY uid, fecha", arrayOfString);
  }
}

