package com.mikki.dataoncount;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TextView;
import java.util.ArrayList;

public class AplicacionesActivity
  extends Activity
{
  private void Inicializa()
  {
    String str = VerTodasLasAplicaciones();
    ((TextView)findViewById(2131230745)).setText(str);
  }
  
  private String VerTodasLasAplicaciones()
  {
    ArrayList localArrayList = new Trafico().ConsultaTraficoAplicaciones(this);
    return new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(getResources().getString(2131165321))).append(" ").append(Integer.toString(localArrayList.size())).toString())).append("\n").toString() + new Util().ArrayToStringLargo(localArrayList, Integer.valueOf(1000), this);
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903041);
    Inicializa();
  }
}


