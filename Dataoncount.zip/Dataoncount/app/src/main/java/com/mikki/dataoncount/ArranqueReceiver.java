package com.mikki.dataoncount;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.SystemClock;

public class ArranqueReceiver
  extends BroadcastReceiver
{
  CDIBD accesoBD;
  Configuracion confActual;
  
  private void ActivaAlarma(Context paramContext)
  {
    try
    {
      Intent localIntent = new Intent(paramContext, Alarma.class);
      localIntent.putExtra("EsAutomatico", this.confActual.automatico);
      localIntent.putExtra("Posicion", 1);
      localIntent.putExtra("Desde", "Arranque");
      PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, 0, localIntent, 134217728);
      int i = this.confActual.frecuencia;
      long l = 120000L + SystemClock.elapsedRealtime();
      ((AlarmManager)paramContext.getSystemService("alarm")).setRepeating(2, l, 1000 * (i * 60), localPendingIntent);
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(paramContext, "Error 174: " + localException.getMessage());
    }
  }
  
  private void Inicialitza(Context paramContext)
  {
    if (this.accesoBD == null) {
      this.accesoBD = new CDIBD(paramContext, null, ConsumoDatosInternetActivity.versionBD);
    }
    SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
    this.confActual = new Configuracion();
    this.confActual.CargaConfiguracion(localSQLiteDatabase, paramContext);
    ActivaAlarma(paramContext);
    this.accesoBD.CierraBD(localSQLiteDatabase);
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    new Intent(paramContext, ConsumoDatosInternetActivity.class).addFlags(268435456);
    Inicialitza(paramContext);
  }
}

