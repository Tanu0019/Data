package com.mikki.dataoncount;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;

public class BDContadores
{
  public static final String CamposCreacion = " (id integer primary key autoincrement, tipo integer, num integer, diaIni integer, mbNoti integer, avisado integer, fechaSiguienteAviso string) ";
  public static final String CamposInsercion = " (tipo, num, diaIni, mbNoti, avisado, fechaSiguienteAviso) ";
  public static final String InsertSample1 = "INSERT INTO Contadores (tipo, num, diaIni, mbNoti, avisado, fechaSiguienteAviso)  VALUES (20, 1, 1, 0, 0, '20120101000000') ";
  public static final String InsertSample2 = "INSERT INTO Contadores (tipo, num, diaIni, mbNoti, avisado, fechaSiguienteAviso)  VALUES (50, 1, 1, 0, 0, '20120101000000') ";
  public static final String TableName = "Contadores";
  public static final String sqlCreate = "CREATE TABLE Contadores (id integer primary key autoincrement, tipo integer, num integer, diaIni integer, mbNoti integer, avisado integer, fechaSiguienteAviso string) ";
  public static final String sqlCreateIfNotExists = "CREATE TABLE if not exists Contadores (id integer primary key autoincrement, tipo integer, num integer, diaIni integer, mbNoti integer, avisado integer, fechaSiguienteAviso string) ";
  public static final String sqlDeleteTable = "DROP TABLE IF EXISTS Contadores";
  public static int tipoDiario = 10;
  public static int tipoMensual;
  public static int tipoSemanal = 20;
  public static int tipoTotal = 60;
  public static int tipoUltimaSemana = 30;
  public static int tipoUltimoMes;
  public int avisado;
  public int diaIni;
  public String fechaSiguienteAviso;
  public int id;
  public int mbNoti;
  public int num;
  public int tipo;
  
  static
  {
    tipoMensual = 40;
    tipoUltimoMes = 50;
  }
  
  public void Avisado(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean, String paramString, int paramInt)
  {
    StringBuilder localStringBuilder;
    if (paramSQLiteDatabase != null)
    {
      localStringBuilder = new StringBuilder("UPDATE Contadores SET avisado=");
      if (!paramBoolean) {

      }
    }
    label62:
    for (int i = 1;; i = 0)
    {
      paramSQLiteDatabase.execSQL(Integer.toString(i) + ", fechaSiguienteAviso='" + paramString + "' WHERE id=" + Integer.toString(paramInt));
      return;
    }
  }
  
  public void Elimina(SQLiteDatabase paramSQLiteDatabase, int paramInt)
  {
    paramSQLiteDatabase.execSQL("DELETE FROM Contadores WHERE id=" + Integer.toString(paramInt));
  }
  
  public void Inserta(SQLiteDatabase paramSQLiteDatabase)
  {
    paramSQLiteDatabase.execSQL("INSERT INTO Contadores (tipo, num, diaIni, mbNoti, avisado, fechaSiguienteAviso)  VALUES  (" + this.tipo + ", " + this.num + ", " + this.diaIni + "," + this.mbNoti + "," + this.avisado + ", '" + this.fechaSiguienteAviso + "')");
  }
  
  public ArrayList<BDContadores> SeleccionaContadores(SQLiteDatabase paramSQLiteDatabase)
  {
    String[] arrayOfString = new String[0];
    ArrayList localArrayList = new ArrayList();
    Cursor localCursor = paramSQLiteDatabase.rawQuery(" SELECT id, tipo, num, diaIni, mbNoti, avisado, fechaSiguienteAviso FROM Contadores ORDER BY tipo ", arrayOfString);
    if (localCursor.moveToFirst()) {
      do
      {
        BDContadores localBDContadores = new BDContadores();
        localBDContadores.id = localCursor.getInt(0);
        localBDContadores.tipo = localCursor.getInt(1);
        localBDContadores.num = localCursor.getInt(2);
        localBDContadores.diaIni = localCursor.getInt(3);
        localBDContadores.mbNoti = localCursor.getInt(4);
        localBDContadores.avisado = localCursor.getInt(5);
        localBDContadores.fechaSiguienteAviso = localCursor.getString(6);
        localArrayList.add(localBDContadores);
      } while (localCursor.moveToNext());
    }
    localCursor.close();
    return localArrayList;
  }
  
  public ArrayList<BDContadores> SeleccionaContadoresConNotificacion(SQLiteDatabase paramSQLiteDatabase)
  {
    String[] arrayOfString = new String[0];
    ArrayList localArrayList = new ArrayList();
    Cursor localCursor = paramSQLiteDatabase.rawQuery(" SELECT id, tipo, num, diaIni, mbNoti, avisado, fechaSiguienteAviso FROM Contadores WHERE mbNoti>0 ORDER BY tipo ", arrayOfString);
    if (localCursor.moveToFirst()) {
      do
      {
        BDContadores localBDContadores = new BDContadores();
        localBDContadores.id = localCursor.getInt(0);
        localBDContadores.tipo = localCursor.getInt(1);
        localBDContadores.num = localCursor.getInt(2);
        localBDContadores.diaIni = localCursor.getInt(3);
        localBDContadores.mbNoti = localCursor.getInt(4);
        localBDContadores.avisado = localCursor.getInt(5);
        localBDContadores.fechaSiguienteAviso = localCursor.getString(6);
        localArrayList.add(localBDContadores);
      } while (localCursor.moveToNext());
    }
    localCursor.close();
    return localArrayList;
  }
}


