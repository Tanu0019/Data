package com.mikki.dataoncount;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.Calendar;

public class BDDiaInstalacion
{
  public static final String CamposCreacion = " (id integer primary key autoincrement, fecha string) ";
  public static final String CamposInsercion = " (fecha) ";
  public static final String TableName = "DiaInstalacion";
  public static final String sqlCreate = "CREATE TABLE DiaInstalacion (id integer primary key autoincrement, fecha string) ";
  public static final String sqlCreateIfNotExists = "CREATE TABLE if not exists DiaInstalacion (id integer primary key autoincrement, fecha string) ";
  public static final String sqlDeleteTable = "DROP TABLE IF EXISTS DiaInstalacion";
  
  private void Inserta(SQLiteDatabase paramSQLiteDatabase, Calendar paramCalendar)
  {
    paramSQLiteDatabase.execSQL("INSERT INTO DiaInstalacion (fecha)  VALUES ('" + Util.FormatoFecha(paramCalendar) + "')");
  }
  
  public Calendar SeleccionaDiaInstalacion(SQLiteDatabase paramSQLiteDatabase)
  {
    String[] arrayOfString = new String[0];
    Calendar localCalendar = Calendar.getInstance();
    Cursor localCursor = paramSQLiteDatabase.rawQuery(" SELECT id, fecha FROM DiaInstalacion ORDER BY fecha ASC ", arrayOfString);
    if (localCursor.moveToFirst()) {
      localCalendar = Util.FormatoFecha(localCursor.getString(1));
    }
    for (;;)
    {
      localCursor.close();

      Inserta(paramSQLiteDatabase, localCalendar);
      return localCalendar;
    }
  }
}


