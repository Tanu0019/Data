package com.mikki.dataoncount;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */