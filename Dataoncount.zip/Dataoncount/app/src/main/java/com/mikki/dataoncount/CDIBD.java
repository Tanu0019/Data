package com.mikki.dataoncount;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CDIBD
  extends SQLiteOpenHelper
{
  public CDIBD(Context paramContext, CursorFactory paramCursorFactory, int paramInt)
  {
    super(paramContext, ConsumoDatosInternetActivity.nomBD, paramCursorFactory, paramInt);
  }
  
  private void ActualitzaBD(SQLiteDatabase paramSQLiteDatabase)
  {
    ActualitzaTaula(paramSQLiteDatabase, "Estadisticas", "CREATE TABLE if not exists Estadisticas (id integer primary key autoincrement, fecha string, movilRX long, movilTX long, totalRX long, totalTX long) ", "CREATE TABLE Estadisticas (id integer primary key autoincrement, fecha string, movilRX long, movilTX long, totalRX long, totalTX long) ");
    ActualitzaTaula(paramSQLiteDatabase, "Configuracion", "CREATE TABLE if not exists Configuracion (id integer primary key autoincrement, diaFactura INTEGER, mbContratados INTEGER, frecuencia INTEGER, automatico INTEGER, ultimosDias INTEGER, notificaciones INTEGER DEFAULT 1, guardaLog INTEGER DEFAULT 0, avisado INTEGER DEFAULT 0) ", "CREATE TABLE Configuracion (id integer primary key autoincrement, diaFactura INTEGER, mbContratados INTEGER, frecuencia INTEGER, automatico INTEGER, ultimosDias INTEGER, notificaciones INTEGER DEFAULT 1, guardaLog INTEGER DEFAULT 0, avisado INTEGER DEFAULT 0) ");
    ActualitzaTaula(paramSQLiteDatabase, "Aplicaciones", "CREATE TABLE if not exists Aplicaciones (id integer primary key autoincrement, fecha string, uid integer, appname string, movilRX long, movilTX long) ", "CREATE TABLE Aplicaciones (id integer primary key autoincrement, fecha string, uid integer, appname string, movilRX long, movilTX long) ");
    ActualitzaTaula(paramSQLiteDatabase, "Contadores", "CREATE TABLE if not exists Contadores (id integer primary key autoincrement, tipo integer, num integer, diaIni integer, mbNoti integer, avisado integer, fechaSiguienteAviso string) ", "CREATE TABLE Contadores (id integer primary key autoincrement, tipo integer, num integer, diaIni integer, mbNoti integer, avisado integer, fechaSiguienteAviso string) ");
    ActualitzaTaula(paramSQLiteDatabase, "DiaInstalacion", "CREATE TABLE if not exists DiaInstalacion (id integer primary key autoincrement, fecha string) ", "CREATE TABLE DiaInstalacion (id integer primary key autoincrement, fecha string) ");
  }
  
  private void ActualitzaTaula(SQLiteDatabase paramSQLiteDatabase, String paramString1, String paramString2, String paramString3)
  {
    String str1 = paramString2;
    try
    {
      paramSQLiteDatabase.execSQL(str1);
      List localList = GetColumns(paramSQLiteDatabase, paramString1);
      str1 = "ALTER table " + paramString1 + " RENAME TO 'temp_" + paramString1 + "'";
      paramSQLiteDatabase.execSQL(str1);
      str1 = paramString3;
      paramSQLiteDatabase.execSQL(str1);
      localList.retainAll(GetColumns(paramSQLiteDatabase, paramString1));
      String str2 = Join(localList, ",");
      str1 = String.format("INSERT INTO %s (%s) SELECT %s from temp_%s", new Object[] { paramString1, str2, str2, paramString1 });
      paramSQLiteDatabase.execSQL(str1);
      str1 = "DROP table 'temp_" + paramString1 + "'";
      paramSQLiteDatabase.execSQL(str1);
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog("Error 872:" + localException.getMessage() + " SQL: " + str1 + " / " + paramString1 + " / " + paramString2 + " / " + paramString3);
    }
  }
  
  private List<String> GetColumns(SQLiteDatabase paramSQLiteDatabase, String paramString)
  {
    Cursor localCursor = null;
    ArrayList localObject2;
    try
    {
      localCursor = paramSQLiteDatabase.rawQuery("select * from " + paramString + " limit 1", null);
      localObject2 = null;
      if (localCursor != null)
      {
        ArrayList localArrayList = new ArrayList(Arrays.asList(localCursor.getColumnNames()));
        localObject2 = localArrayList;
      }
    }
    catch (Exception localException)
    {
      Log.v(paramString, localException.getMessage(), localException);
      localException.printStackTrace();
      localObject2 = null;
      return null;
    }
    finally
    {
      if (localCursor == null) {

      }
      localCursor.close();
    }
    return (List<String>)localObject2;
  }
  
  private String Join(List<String> paramList, String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = paramList.size();
    for (int j = 0;; j++)
    {
      if (j >= i) {
        return localStringBuilder.toString();
      }
      if (j != 0) {
        localStringBuilder.append(paramString);
      }
      localStringBuilder.append((String)paramList.get(j));
    }
  }
  
  public SQLiteDatabase AbreBD()
  {
    return getWritableDatabase();
  }
  
  public void CierraBD(SQLiteDatabase paramSQLiteDatabase)
  {
    if (paramSQLiteDatabase != null) {
      paramSQLiteDatabase.close();
    }
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase)
  {
    paramSQLiteDatabase.execSQL("CREATE TABLE Estadisticas (id integer primary key autoincrement, fecha string, movilRX long, movilTX long, totalRX long, totalTX long) ");
    paramSQLiteDatabase.execSQL("CREATE TABLE Configuracion (id integer primary key autoincrement, diaFactura INTEGER, mbContratados INTEGER, frecuencia INTEGER, automatico INTEGER, ultimosDias INTEGER, notificaciones INTEGER DEFAULT 1, guardaLog INTEGER DEFAULT 0, avisado INTEGER DEFAULT 0) ");
    paramSQLiteDatabase.execSQL("CREATE TABLE Aplicaciones (id integer primary key autoincrement, fecha string, uid integer, appname string, movilRX long, movilTX long) ");
    paramSQLiteDatabase.execSQL("CREATE TABLE Contadores (id integer primary key autoincrement, tipo integer, num integer, diaIni integer, mbNoti integer, avisado integer, fechaSiguienteAviso string) ");
    paramSQLiteDatabase.execSQL("INSERT INTO Contadores (tipo, num, diaIni, mbNoti, avisado, fechaSiguienteAviso)  VALUES (20, 1, 1, 0, 0, '20120101000000') ");
    paramSQLiteDatabase.execSQL("INSERT INTO Contadores (tipo, num, diaIni, mbNoti, avisado, fechaSiguienteAviso)  VALUES (50, 1, 1, 0, 0, '20120101000000') ");
    paramSQLiteDatabase.execSQL("CREATE TABLE DiaInstalacion (id integer primary key autoincrement, fecha string) ");
  }
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
  {
    ActualitzaBD(paramSQLiteDatabase);
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\CDIBD.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */