package com.mikki.dataoncount;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class Configuracion
{
  public static final String Campos = " (id integer primary key autoincrement, diaFactura INTEGER, mbContratados INTEGER, frecuencia INTEGER, automatico INTEGER, ultimosDias INTEGER, notificaciones INTEGER DEFAULT 1, guardaLog INTEGER DEFAULT 0, avisado INTEGER DEFAULT 0) ";
  public static final String TableName = "Configuracion";
  public static final String sqlCreate = "CREATE TABLE Configuracion (id integer primary key autoincrement, diaFactura INTEGER, mbContratados INTEGER, frecuencia INTEGER, automatico INTEGER, ultimosDias INTEGER, notificaciones INTEGER DEFAULT 1, guardaLog INTEGER DEFAULT 0, avisado INTEGER DEFAULT 0) ";
  public static final String sqlCreateIfNotExists = "CREATE TABLE if not exists Configuracion (id integer primary key autoincrement, diaFactura INTEGER, mbContratados INTEGER, frecuencia INTEGER, automatico INTEGER, ultimosDias INTEGER, notificaciones INTEGER DEFAULT 1, guardaLog INTEGER DEFAULT 0, avisado INTEGER DEFAULT 0) ";
  public static final String sqlDeleteTable = "DROP TABLE IF EXISTS Configuracion";
  public int automatico;
  public int avisado;
  public int diaFactura;
  public int frecuencia;
  public int guardaLog;
  public int mbContratados;
  public int notificaciones;
  public int ultimosDias;
  
  public void Avisado(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean)
  {
    if (paramSQLiteDatabase != null) {
      if (!paramBoolean) {

      }
    }
    label42:
    for (int i = 1;; i = 0)
    {
      this.avisado = i;
      paramSQLiteDatabase.execSQL("UPDATE Configuracion SET avisado=" + Integer.toString(this.avisado));
      return;
    }
  }
  
  /* Error */
  public boolean CargaConfiguracion(SQLiteDatabase paramSQLiteDatabase, Context paramContext)
  {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield 68	com/si/datausage/Configuracion:mbContratados	I
    //   5: aload_0
    //   6: iconst_0
    //   7: putfield 70	com/si/datausage/Configuracion:diaFactura	I
    //   10: iconst_0
    //   11: istore_3
    //   12: aload_1
    //   13: ldc 72
    //   15: iconst_0
    //   16: anewarray 74	java/lang/String
    //   19: invokevirtual 78	android/database/sqlite/SQLiteDatabase:rawQuery	(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   22: astore 5
    //   24: aload 5
    //   26: invokeinterface 84 1 0
    //   31: istore 6
    //   33: iload 6
    //   35: ifeq +315 -> 350
    //   38: aload_0
    //   39: aload 5
    //   41: iconst_0
    //   42: invokeinterface 88 2 0
    //   47: putfield 70	com/si/datausage/Configuracion:diaFactura	I
    //   50: aload_0
    //   51: aload 5
    //   53: iconst_1
    //   54: invokeinterface 88 2 0
    //   59: putfield 68	com/si/datausage/Configuracion:mbContratados	I
    //   62: aload_0
    //   63: aload 5
    //   65: iconst_2
    //   66: invokeinterface 88 2 0
    //   71: putfield 90	com/si/datausage/Configuracion:frecuencia	I
    //   74: aload_0
    //   75: aload 5
    //   77: iconst_3
    //   78: invokeinterface 88 2 0
    //   83: putfield 92	com/si/datausage/Configuracion:automatico	I
    //   86: aload_0
    //   87: aload 5
    //   89: iconst_4
    //   90: invokeinterface 88 2 0
    //   95: putfield 94	com/si/datausage/Configuracion:ultimosDias	I
    //   98: aload_0
    //   99: aload 5
    //   101: iconst_5
    //   102: invokeinterface 88 2 0
    //   107: putfield 96	com/si/datausage/Configuracion:notificaciones	I
    //   110: aload_0
    //   111: aload 5
    //   113: bipush 6
    //   115: invokeinterface 88 2 0
    //   120: putfield 98	com/si/datausage/Configuracion:guardaLog	I
    //   123: aload_0
    //   124: aload 5
    //   126: bipush 7
    //   128: invokeinterface 88 2 0
    //   133: putfield 37	com/si/datausage/Configuracion:avisado	I
    //   136: aload 5
    //   138: invokeinterface 101 1 0
    //   143: iload_3
    //   144: ireturn
    //   145: astore 7
    //   147: aload_0
    //   148: aload_2
    //   149: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   152: ldc 108
    //   154: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   157: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   160: putfield 70	com/si/datausage/Configuracion:diaFactura	I
    //   163: goto -113 -> 50
    //   166: astore 4
    //   168: new 119	com/si/datausage/Util
    //   171: dup
    //   172: invokespecial 120	com/si/datausage/Util:<init>	()V
    //   175: aload_2
    //   176: new 39	java/lang/StringBuilder
    //   179: dup
    //   180: ldc 122
    //   182: invokespecial 44	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   185: aload 4
    //   187: invokevirtual 125	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   190: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: invokevirtual 57	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   196: invokevirtual 129	com/si/datausage/Util:WriteLog	(Landroid/content/Context;Ljava/lang/String;)V
    //   199: iload_3
    //   200: ireturn
    //   201: astore 8
    //   203: aload_0
    //   204: aload_2
    //   205: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   208: ldc -126
    //   210: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   213: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   216: putfield 68	com/si/datausage/Configuracion:mbContratados	I
    //   219: goto -157 -> 62
    //   222: astore 9
    //   224: aload_0
    //   225: aload_2
    //   226: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   229: ldc -125
    //   231: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   234: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   237: putfield 90	com/si/datausage/Configuracion:frecuencia	I
    //   240: goto -166 -> 74
    //   243: astore 10
    //   245: aload_0
    //   246: aload_2
    //   247: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   250: ldc -124
    //   252: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   255: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   258: putfield 92	com/si/datausage/Configuracion:automatico	I
    //   261: goto -175 -> 86
    //   264: astore 11
    //   266: aload_0
    //   267: aload_2
    //   268: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   271: ldc -123
    //   273: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   276: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   279: putfield 94	com/si/datausage/Configuracion:ultimosDias	I
    //   282: goto -184 -> 98
    //   285: astore 12
    //   287: aload_0
    //   288: aload_2
    //   289: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   292: ldc -122
    //   294: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   297: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   300: putfield 96	com/si/datausage/Configuracion:notificaciones	I
    //   303: goto -193 -> 110
    //   306: astore 13
    //   308: aload_0
    //   309: aload_2
    //   310: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   313: ldc -121
    //   315: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   318: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   321: putfield 98	com/si/datausage/Configuracion:guardaLog	I
    //   324: goto -201 -> 123
    //   327: astore 14
    //   329: aload_0
    //   330: aload_2
    //   331: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   334: ldc -120
    //   336: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   339: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   342: putfield 37	com/si/datausage/Configuracion:avisado	I
    //   345: iconst_0
    //   346: istore_3
    //   347: goto -211 -> 136
    //   350: aload_0
    //   351: new 138	com/si/datausage/BDDiaInstalacion
    //   354: dup
    //   355: invokespecial 139	com/si/datausage/BDDiaInstalacion:<init>	()V
    //   358: aload_1
    //   359: invokevirtual 143	com/si/datausage/BDDiaInstalacion:SeleccionaDiaInstalacion	(Landroid/database/sqlite/SQLiteDatabase;)Ljava/util/Calendar;
    //   362: iconst_5
    //   363: invokevirtual 148	java/util/Calendar:get	(I)I
    //   366: putfield 70	com/si/datausage/Configuracion:diaFactura	I
    //   369: aload_0
    //   370: aload_2
    //   371: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   374: ldc -126
    //   376: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   379: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   382: putfield 68	com/si/datausage/Configuracion:mbContratados	I
    //   385: aload_0
    //   386: aload_2
    //   387: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   390: ldc -125
    //   392: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   395: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   398: putfield 90	com/si/datausage/Configuracion:frecuencia	I
    //   401: aload_0
    //   402: aload_2
    //   403: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   406: ldc -124
    //   408: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   411: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   414: putfield 92	com/si/datausage/Configuracion:automatico	I
    //   417: aload_0
    //   418: aload_2
    //   419: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   422: ldc -123
    //   424: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   427: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   430: putfield 94	com/si/datausage/Configuracion:ultimosDias	I
    //   433: aload_0
    //   434: aload_2
    //   435: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   438: ldc -122
    //   440: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   443: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   446: putfield 96	com/si/datausage/Configuracion:notificaciones	I
    //   449: aload_0
    //   450: aload_2
    //   451: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   454: ldc -121
    //   456: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   459: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   462: putfield 98	com/si/datausage/Configuracion:guardaLog	I
    //   465: aload_0
    //   466: aload_2
    //   467: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   470: ldc -120
    //   472: invokevirtual 113	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   475: invokestatic 117	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   478: putfield 37	com/si/datausage/Configuracion:avisado	I
    //   481: aload_0
    //   482: aload_1
    //   483: invokevirtual 152	com/si/datausage/Configuracion:InsertaConfiguracion	(Landroid/database/sqlite/SQLiteDatabase;)V
    //   486: iconst_1
    //   487: istore_3
    //   488: goto -352 -> 136
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	491	0	this	Configuracion
    //   0	491	1	paramSQLiteDatabase	SQLiteDatabase
    //   0	491	2	paramContext	android.content.Context
    //   11	477	3	bool1	boolean
    //   166	20	4	localException1	Exception
    //   22	115	5	localCursor	android.database.Cursor
    //   31	3	6	bool2	boolean
    //   145	1	7	localException2	Exception
    //   201	1	8	localException3	Exception
    //   222	1	9	localException4	Exception
    //   243	1	10	localException5	Exception
    //   264	1	11	localException6	Exception
    //   285	1	12	localException7	Exception
    //   306	1	13	localException8	Exception
    //   327	1	14	localException9	Exception
    // Exception table:
    //   from	to	target	type
    //   38	50	145	java/lang/Exception
    //   12	33	166	java/lang/Exception
    //   136	143	166	java/lang/Exception
    //   147	163	166	java/lang/Exception
    //   203	219	166	java/lang/Exception
    //   224	240	166	java/lang/Exception
    //   245	261	166	java/lang/Exception
    //   266	282	166	java/lang/Exception
    //   287	303	166	java/lang/Exception
    //   308	324	166	java/lang/Exception
    //   329	345	166	java/lang/Exception
    //   350	486	166	java/lang/Exception
    //   50	62	201	java/lang/Exception
    //   62	74	222	java/lang/Exception
    //   74	86	243	java/lang/Exception
    //   86	98	264	java/lang/Exception
    //   98	110	285	java/lang/Exception
    //   110	123	306	java/lang/Exception
    //   123	136	327	java/lang/Exception
    return false;
  }
  
  public void InsertaConfiguracion(SQLiteDatabase paramSQLiteDatabase)
  {
    if (paramSQLiteDatabase != null)
    {
      paramSQLiteDatabase.execSQL("DELETE FROM Configuracion ");
      paramSQLiteDatabase.execSQL("INSERT INTO Configuracion (diaFactura, MbContratados, frecuencia, automatico, ultimosDias, notificaciones, guardaLog, avisado) VALUES (" + Integer.toString(this.diaFactura) + ", " + Integer.toString(this.mbContratados) + ", " + Integer.toString(this.frecuencia) + ", " + Integer.toString(this.automatico) + ", " + Integer.toString(this.ultimosDias) + ", " + Integer.toString(this.notificaciones) + ", " + Integer.toString(this.guardaLog) + ", " + Integer.toString(this.avisado) + ")");
      if (this.notificaciones > 0)
      {
        paramSQLiteDatabase.execSQL("UPDATE Configuracion SET avisado=0 ");
        paramSQLiteDatabase.execSQL("UPDATE Contadores SET avisado=0 ");
      }
    }
  }
}

