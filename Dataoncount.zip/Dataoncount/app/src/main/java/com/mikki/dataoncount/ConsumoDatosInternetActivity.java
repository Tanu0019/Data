package com.mikki.dataoncount;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RemoteViews;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

//import com.google.android.gms.ads.AdRequest;
//import com.google.android.gms.ads.AdRequest.Builder;
//import com.google.android.gms.ads.AdView;
//import com.google.android.gms.ads.InterstitialAd;

public class ConsumoDatosInternetActivity
  extends Activity
{
  private static final int MNU_OPC1 = 1;
  private static final int MNU_OPC2 = 2;
  private static final int MNU_OPC3 = 3;
  private static final int MNU_OPC4 = 4;
  private static final int MNU_OPC5 = 5;
  private static final int MNU_OPC6 = 6;
  public static String app = "PRO";
  public static String nomBD = "CDIBD";
  public static String nomFitxer = "PrCDI.txt";
  public static int versionBD = 12;
  CDIBD accesoBD;
  //private AdRequest adRequest;
  //private AdView adView;
  Configuracion confActual;
  //private InterstitialAd interstitial;
  Toast mToast;
  ProgressDialog progressD;
  
  private void ActivaAlarma()
  {
    try
    {
      Intent localIntent = new Intent(this, Alarma.class);
      localIntent.putExtra("EsAutomatico", this.confActual.automatico);
      localIntent.putExtra("Posicion", 1);
      localIntent.putExtra("Desde", "Activity");
      PendingIntent localPendingIntent = PendingIntent.getBroadcast(this, 0, localIntent, 134217728);
      int i = this.confActual.frecuencia;
      long l = SystemClock.elapsedRealtime() + 1000 * (i * 60);
      ((AlarmManager)getSystemService("alarm")).setRepeating(2, l, 1000 * (i * 60), localPendingIntent);
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(this, "Error 144: " + localException.getMessage());
      this.mToast = Toast.makeText(this, "Error al activar alarma", 1);
      this.mToast.show();
    }
  }
  
  private void ActualizaApps(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      Trafico localTrafico = new Trafico();
      Aplicaciones localAplicaciones = new Aplicaciones();
      Util localUtil = new Util();
      Calendar localCalendar1 = Calendar.getInstance();
      Calendar localCalendar2 = Calendar.getInstance();
      localCalendar2.add(5, -1 * this.confActual.ultimosDias);
      ArrayList localArrayList1 = localTrafico.SumaBytesPorAplicaciones(localAplicaciones.SeleccionaEntreFechas(paramSQLiteDatabase, localCalendar2, localCalendar1), this);
      if (localArrayList1.size() < 5) {
        localArrayList1 = localTrafico.Rellena(this, localArrayList1);
      }
      localUtil.ArrayToTableLayoutCorto(localArrayList1, Integer.valueOf(5), (TableLayout)findViewById(2131230795), this);
      String str = Integer.toString(this.confActual.ultimosDias) + " " + getResources().getString(2131165247);
      ((TextView)findViewById(2131230793)).setText(str);
      ArrayList localArrayList2 = localTrafico.SumaBytesPorAplicaciones(localAplicaciones.SeleccionaDesdeDia(paramSQLiteDatabase, localCalendar1), this);
      if (localArrayList2.size() < 5) {
        localArrayList2 = localTrafico.Rellena(this, localArrayList2);
      }
      localUtil.ArrayToTableLayoutCorto(localArrayList2, Integer.valueOf(5), (TableLayout)findViewById(2131230791), this);
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(this, "Error 124: " + localException.getMessage());
      this.mToast = Toast.makeText(this, "Error al actualizar listado de aplicaciones", 1);
      this.mToast.show();
    }
  }
  
  public static void ActualizaBarras(boolean paramBoolean, RemoteViews paramRemoteViews, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Configuracion paramConfiguracion, Context paramContext, SQLiteDatabase paramSQLiteDatabase)
  {
    Trafico localTrafico = new Trafico();
    Calendar localCalendar = Calendar.getInstance();
    GregorianCalendar localGregorianCalendar1 = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    localGregorianCalendar1.set(localCalendar.get(1), localCalendar.get(2), paramConfiguracion.diaFactura, 0, 0, 0);
    if (localCalendar.get(5) < paramConfiguracion.diaFactura) {
      localGregorianCalendar1.add(2, -1);
    }
    GregorianCalendar localGregorianCalendar2 = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    localGregorianCalendar2.set(localGregorianCalendar1.get(1), localGregorianCalendar1.get(2), localGregorianCalendar1.get(5), 0, 0, 0);
    localGregorianCalendar2.add(2, 1);
    long l1 = localGregorianCalendar1.getTime().getTime();
    int i = Double.valueOf(Math.floor((localGregorianCalendar2.getTime().getTime() - l1) / 86400000L)).intValue();
    long l2 = localGregorianCalendar1.getTime().getTime();
    Double localDouble1 = Double.valueOf(1.0D + Double.valueOf(Math.floor((localCalendar.getTime().getTime() - l2) / 86400000L)).doubleValue());
    int j = localDouble1.intValue();
    String str1 = paramContext.getResources().getString(2131165311);
    String str2 = Integer.toString(localDouble1.intValue()) + " / " + Integer.toString(i) + " " + paramContext.getResources().getString(2131165291);
    String str3 = paramContext.getResources().getString(2131165235) + " " + Integer.toString(localDouble1.intValue()) + " " + str1 + " " + Integer.toString(i);
    int k = 1024 * paramConfiguracion.mbContratados;
    Double localDouble2 = Double.valueOf(localTrafico.SumaBytes(new Estadisticas().SeleccionaDesdeDia(paramSQLiteDatabase, localGregorianCalendar1), paramContext, "Estadisticas").doubleValue() / 1024.0D);
    int m = localDouble2.intValue();
    String str4 = "3G: " + Util.FormatoDecimal(Double.valueOf(localDouble2.doubleValue() / 1024.0D)) + " / " + Integer.toString(paramConfiguracion.mbContratados) + " Mb";
    String str5 = paramContext.getResources().getString(2131165234) + " " + Util.FormatoDecimal(Double.valueOf(localDouble2.doubleValue() / 1024.0D)) + " " + str1 + " " + Integer.toString(paramConfiguracion.mbContratados) + " Mb";
    if (paramBoolean)
    {
      paramRemoteViews.setProgressBar(paramInt2, Util.ValorMaximoRelativo, Util.Relativo1000000(i, j), false);
      paramRemoteViews.setTextViewText(paramInt1, str2);
      paramRemoteViews.setProgressBar(paramInt4, Util.ValorMaximoRelativo, Util.Relativo1000000(k, m), false);
      paramRemoteViews.setTextViewText(paramInt3, str4);
      return;
    }
    DatosMain.PBDiasMax = Util.ValorMaximoRelativo;
    DatosMain.PBDiasProgress = Util.Relativo1000000(i, j);
    DatosMain.TVDiasDesdeUltimaFactura = str3;
    DatosMain.PBMbMax = Util.ValorMaximoRelativo;
    DatosMain.PBMbProgress = Util.Relativo1000000(k, m);
    DatosMain.TVMbConsumidos = str5;
    AppWidgetManager localAppWidgetManager = AppWidgetManager.getInstance(paramContext);
    RemoteViews localRemoteViews = new RemoteViews(paramContext.getPackageName(), 2130903053);
    ComponentName localComponentName = new ComponentName(paramContext, Wi.class);
    localRemoteViews.setProgressBar(2131230838, Util.ValorMaximoRelativo, Util.Relativo1000000(i, j), false);
    localRemoteViews.setTextViewText(2131230837, str2);
    localRemoteViews.setProgressBar(2131230840, Util.ValorMaximoRelativo, Util.Relativo1000000(k, m), false);
    localRemoteViews.setTextViewText(2131230839, str4);
    localAppWidgetManager.updateAppWidget(localComponentName, localRemoteViews);
  }
  
  private void ActualizaBarrasMain(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      ActualizaBarras(false, null, 2131230772, 2131230773, 2131230774, 2131230775, this.confActual, this, paramSQLiteDatabase);
      return;
    }
    catch (Exception localException)
    {
      String str = "Error 54: " + localException.getMessage();
      new Util().WriteLog(this, str);
      DatosMain.error = str;
      DatosMain.hayError = true;
    }
  }
  
  private void ActualizaContadores(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      Double.valueOf(0.0D);
      Trafico localTrafico = new Trafico();
      Estadisticas localEstadisticas = new Estadisticas();
      Calendar localCalendar1 = Calendar.getInstance();
      DatosMain.TVHoy2 = Util.FormatoDecimal(Double.valueOf(Double.valueOf(localTrafico.SumaBytes(localEstadisticas.SeleccionaUnDia(paramSQLiteDatabase, localCalendar1), this, "Estadisticas").doubleValue() / 1024.0D).doubleValue() / 1024.0D)) + " Mb";
      Calendar localCalendar2 = Calendar.getInstance();
      localCalendar2.add(5, -1);
      DatosMain.TVAyer2 = Util.FormatoDecimal(Double.valueOf(Double.valueOf(localTrafico.SumaBytes(localEstadisticas.SeleccionaUnDia(paramSQLiteDatabase, localCalendar2), this, "Estadisticas").doubleValue() / 1024.0D).doubleValue() / 1024.0D)) + " Mb";
      int i = -1 * this.confActual.ultimosDias;
      Calendar localCalendar3 = Calendar.getInstance();
      localCalendar3.add(5, i);
      Double localDouble = Double.valueOf(Double.valueOf(localTrafico.SumaBytes(localEstadisticas.SeleccionaEntreFechas(paramSQLiteDatabase, localCalendar3, localCalendar1), this, "Estadisticas").doubleValue() / 1024.0D).doubleValue() / 1024.0D);
      DatosMain.TVUltimosDias = Integer.toString(this.confActual.ultimosDias) + " " + getResources().getString(2131165240) + " ";
      DatosMain.TVUltimosDias2 = Util.FormatoDecimal(localDouble) + " Mb";
      return;
    }
    catch (Exception localException)
    {
      String str = "Error 554: " + localException.getMessage();
      new Util().WriteLog(this, str);
      DatosMain.error = str;
      DatosMain.hayError = true;
    }
  }
  
  private void CalculoDatos()
  {
    SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.add(12, -2);
    if (localCalendar.getTimeInMillis() > DatosMain.fechaUltimaCarga.getTimeInMillis())
    {
      GrabaMuestra(localSQLiteDatabase);
      DatosMain.fechaUltimaCarga = Calendar.getInstance();
    }
    ActualizaBarrasMain(localSQLiteDatabase);
    ActualizaContadores(localSQLiteDatabase);
    this.accesoBD.CierraBD(localSQLiteDatabase);
  }
  
  private void CargaDatosEnPantalla()
  {
    ProgressBar localProgressBar1 = (ProgressBar)findViewById(2131230773);
    ProgressBar localProgressBar2 = (ProgressBar)findViewById(2131230775);
    TextView localTextView1 = (TextView)findViewById(2131230772);
    TextView localTextView2 = (TextView)findViewById(2131230774);
    localProgressBar1.setMax(DatosMain.PBDiasMax);
    localProgressBar1.setProgress(DatosMain.PBDiasProgress);
    localTextView1.setText(DatosMain.TVDiasDesdeUltimaFactura);
    localProgressBar2.setMax(DatosMain.PBMbMax);
    localProgressBar2.setProgress(DatosMain.PBMbProgress);
    localTextView2.setText(DatosMain.TVMbConsumidos);
    ((TextView)findViewById(2131230787)).setText(DatosMain.TVUltimosDias2);
    ((TextView)findViewById(2131230786)).setText(DatosMain.TVUltimosDias);
    ((TextView)findViewById(2131230779)).setText(DatosMain.TVHoy2);
    ((TextView)findViewById(2131230783)).setText(DatosMain.TVAyer2);
    Ver(true);
    if (DatosMain.hayError)
    {
      DatosMain.hayError = false;
      this.mToast = Toast.makeText(this, getResources().getString(2131165312), 1);
      this.mToast.show();
    }
  }
  
  private void CargaInicial()
  {
    Ver(false);
    SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
    this.confActual = new Configuracion();
    boolean bool = this.confActual.CargaConfiguracion(localSQLiteDatabase, this);
    DiasSemana();
    ActivaAlarma();
    if (bool)
    {
      GrabaMuestra(localSQLiteDatabase);
      VerPantallaBienvenida();
    }
    ActualizaApps(localSQLiteDatabase);
    this.accesoBD.CierraBD(localSQLiteDatabase);
  }
  
  private void DiasSemana()
  {
    TextView localTextView1 = (TextView)findViewById(2131230777);
    Calendar localCalendar = Calendar.getInstance();
    localTextView1.setText(ContadoresUtil.DiaSemana(localCalendar.get(7), this));
    TextView localTextView2 = (TextView)findViewById(2131230781);
    localCalendar.add(5, -1);
    localTextView2.setText(ContadoresUtil.DiaSemana(localCalendar.get(7), this));
  }
  
  private void GrabaMuestra(SQLiteDatabase paramSQLiteDatabase)
  {
    new Trafico().ConsultaYGuarda(this, "GM", paramSQLiteDatabase);
  }
  
  private void Inicializa()
  {
    CargaInicial();
    new ConsultasAsicronas(null).execute(new Void[0]);
  }
  
  private void Ver(boolean paramBoolean)
  {
    if (paramBoolean) {}
    for (int i = 0;; i = 4)
    {
      ((TableLayout)findViewById(2131230776)).setVisibility(i);
      ((TableRow)findViewById(2131230788)).setVisibility(i);
      ((TableRow)findViewById(2131230790)).setVisibility(i);
      ((TableRow)findViewById(2131230792)).setVisibility(i);
      ((TableRow)findViewById(2131230794)).setVisibility(i);
      return;
    }
  }
  
  private void VerAcercaDe()
  {
    String str1 = getResources().getString(2131165256);
    String str2 = getResources().getString(2131165254);
    if (app == "PRO")
    {
      str1 = str1 + getResources().getString(2131165257);
      str2 = getResources().getString(2131165255);
    }
    Util.CreaAlertDialog(this, getResources().getString(2131165309), getResources().getString(2131165224), str2, str1);
  }
  
  private void VerAplicaciones()
  {
    startActivity(new Intent(this, AplicacionesActivity.class));
  }
  
  private void VerContadores()
  {
    startActivity(new Intent(this, ContadoresActivity.class));
  }
  
  private void VerHistorico()
  {
    startActivity(new Intent(this, HistoricoActivity.class));
  }
  
  /*private void VerNuevasFuncionesVersionPro()
  {
    startActivity(new Intent(this, VersionProActivity.class));
  }*/
  
  private void VerPantallaBienvenida()
  {
    ArrayList localArrayList = new Trafico().ConsultaTraficoAplicaciones(this);
    String str1 = getResources().getString(2131165315) + new Util().ArrayToStringCorto(localArrayList, Integer.valueOf(8));
    String str2 = getResources().getString(2131165314);
    String str3 = getResources().getString(2131165316);
    Util.CreaAlertDialog(this, getResources().getString(2131165224), str2, str1, str3);
  }
  
  private void VerPreferencias()
  {
    startActivity(new Intent(this, PreferenciasActivity.class));
  }
  
  private void VerSQLManager()
  {
    startActivity(new Intent(this, SQLActivity.class));
  }
  /*
  public void displayInterstitial()
  {
    if (this.interstitial.isLoaded()) {
      this.interstitial.show();
    }
  }
  
  public void loadInterstitial()
  {
    if (!this.interstitial.isLoaded()) {
      this.interstitial.loadAd(this.adRequest);
    }
  }
  */
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903048);
    DatosMain.fechaUltimaCarga = Calendar.getInstance();
    DatosMain.fechaUltimaCarga.add(1, -1);
    DatosMain.hayError = false;
    try
    {
    /* this.adView = ((AdView)findViewById(2131230767));
      AdRequest localAdRequest = new AdRequest.Builder().build();
      this.adView.loadAd(localAdRequest);
      this.interstitial = new InterstitialAd(this);
      this.interstitial.setAdUnitId("ca-app-pub-3362254087743845/1259862015");
      this.adRequest = new AdRequest.Builder().build();
      this.interstitial.loadAd(this.adRequest);*/
      if (this.accesoBD == null) {
        this.accesoBD = new CDIBD(this, null, versionBD);
      }
      return;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        String str = "Error 1100: " + localException.getMessage();
        new Util().WriteLog(this, str);
        DatosMain.error = str;
        DatosMain.hayError = true;
      }
    }
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    String str1 = getResources().getString(2131165305);
    String str2 = getResources().getString(2131165306);
    String str3 = getResources().getString(2131165307);
    String str4 = getResources().getString(2131165308);
    String str5 = getResources().getString(2131165309);
    String str6 = getResources().getString(2131165310);
    paramMenu.add(0, 1, 0, str1).setIcon(2130837542);
    paramMenu.add(0, 2, 0, str2).setIcon(2130837505);
    paramMenu.add(0, 3, 0, str3).setIcon(2130837534);
    paramMenu.add(0, 4, 0, str4).setIcon(2130837530);
    paramMenu.add(0, 5, 0, str5).setIcon(2130837504);
    paramMenu.add(0, 6, 0, str6).setIcon(2130837543);
    setMenuBackground(paramMenu);
    return true;
  }
  /*
  public void onDestroy()
  {
    try
    {
      this.adView.destroy();
      super.onDestroy();
      displayInterstitial();
      return;
    }
    catch (Exception localException)
    {
      for (;;) {}
    }
  }
  */
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    switch (paramMenuItem.getItemId())
    {
    default: 
      return super.onOptionsItemSelected(paramMenuItem);
    case 1: 
      VerPreferencias();
      return true;
    case 2: 
      VerAplicaciones();
      return true;
    case 3: 
      VerHistorico();
      return true;
    case 4: 
      VerContadores();
      return true;
    case 5: 
      if ((this.confActual.mbContratados == 3156) && (this.confActual.diaFactura == 22) && (this.confActual.ultimosDias == 22))
      {
        VerSQLManager();
        return true;
      }
      VerAcercaDe();
      return true;
    }
   // VerNuevasFuncionesVersionPro();
    //return true;
  }
  /*
  public void onPause()
  {
    try
    {
      this.adView.pause();
      super.onPause();
      return;
    }
    catch (Exception localException)
    {
      for (;;) {}
    }
  }

  public void onResume()
  {
    super.onResume();
    Inicializa();
    try
    {
      this.adView.resume();
      return;
    }
    catch (Exception localException) {}
  }
  */
  public void onStop()
  {
    super.onStop();
  }
  
  protected boolean setMenuBackground(Menu paramMenu)
  {
    getLayoutInflater().setFactory(new Factory()
    {
      public View onCreateView(String paramAnonymousString, Context paramAnonymousContext, AttributeSet paramAnonymousAttributeSet)
      {
        if (paramAnonymousString.equalsIgnoreCase("com.android.internal.view.menu.IconMenuItemView")) {}
        try
        {
          final View localView = LayoutInflater.from(paramAnonymousContext).createView(paramAnonymousString, null, paramAnonymousAttributeSet);
          new Handler().post(new Runnable()
          {
            public void run()
            {
              localView.setBackgroundResource(2131099674);
            }
          });
          return localView;
        }
        catch (ClassNotFoundException localClassNotFoundException)
        {
          return null;
        }
        catch (InflateException localInflateException)
        {
          for (;;) {}
        }
      }
    });
    return super.onCreateOptionsMenu(paramMenu);
  }
  
  private class ConsultasAsicronas
    extends AsyncTask<Void, Void, Void>
  {
    private ConsultasAsicronas(Object o) {}
    
    protected Void doInBackground(Void... paramVarArgs)
    {
      ConsumoDatosInternetActivity.this.CalculoDatos();
      return null;
    }
    
    protected void onPostExecute(Void paramVoid)
    {
      ConsumoDatosInternetActivity.this.CargaDatosEnPantalla();
      if (ConsumoDatosInternetActivity.this.progressD != null) {
        ConsumoDatosInternetActivity.this.progressD.dismiss();
      }
    }
    
    protected void onPreExecute()
    {
      String str = ConsumoDatosInternetActivity.this.getResources().getString(2131165313);
      ConsumoDatosInternetActivity.this.progressD = ProgressDialog.show(ConsumoDatosInternetActivity.this, "", str, true, false);
    }
  }
  
  public static class DatosMain
  {
    public static int PBDiasMax;
    public static int PBDiasProgress;
    public static int PBMbMax;
    public static int PBMbProgress;
    public static String TVAyer2;
    public static String TVDiasDesdeUltimaFactura;
    public static String TVHoy2;
    public static String TVMbConsumidos;
    public static String TVUltimosDias;
    public static String TVUltimosDias2;
    public static String error;
    public static Calendar fechaUltimaCarga;
    public static boolean hayError;
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\ConsumoDatosInternetActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */