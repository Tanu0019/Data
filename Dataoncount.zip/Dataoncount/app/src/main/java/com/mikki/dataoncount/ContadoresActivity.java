package com.mikki.dataoncount;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;

public class ContadoresActivity
  extends Activity
{
  TableLayout TCo;
  CDIBD accesoBD;
  Toast mToast;
  
  private void CargaContadores()
  {
    if (this.accesoBD == null) {
      this.accesoBD = new CDIBD(this, null, ConsumoDatosInternetActivity.versionBD);
    }
    SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
    ArrayList localArrayList = new BDContadores().SeleccionaContadores(localSQLiteDatabase);
    this.TCo.removeAllViews();
    TextView localTextView1 = new TextView(this);
    TextView localTextView2 = new TextView(this);
    TextView localTextView3 = new TextView(this);
    localTextView1.setText(getResources().getString(2131165294) + ": ");
    localTextView2.setText(Integer.toString(localArrayList.size()));
    localTextView3.setText("  ");
    TableRow localTableRow = new TableRow(this);
    localTableRow.addView(localTextView1);
    localTableRow.addView(localTextView2);
    localTableRow.addView(localTextView3);
    this.TCo.addView(localTableRow);
    Iterator localIterator = localArrayList.iterator();
    for (;;)
    {
      if (!localIterator.hasNext())
      {
        this.accesoBD.CierraBD(localSQLiteDatabase);
        return;
      }
      CargaUnContador((BDContadores)localIterator.next(), localSQLiteDatabase);
    }
  }
  
  private void CargaUnContador(BDContadores paramBDContadores, SQLiteDatabase paramSQLiteDatabase)
  {
    ContadoresUtil localContadoresUtil = new ContadoresUtil();
    Calendar localCalendar = localContadoresUtil.Desde(paramBDContadores);
    Double localDouble = localContadoresUtil.CalculaUnContador(localCalendar, paramBDContadores, this, paramSQLiteDatabase);
    TextView localTextView1 = new TextView(this);
    TextView localTextView2 = new TextView(this);
    localTextView1.setText(new ContadoresUtil().DescripcionContador(paramBDContadores, localCalendar, this));
    localTextView2.setText(Util.FormatoDecimal(localDouble) + " Mb");
    if ((paramBDContadores.mbNoti > 0) && (localDouble.doubleValue() > paramBDContadores.mbNoti)) {
      localTextView2.setTextColor(-65536);
    }
    for (;;)
    {
      final int i = paramBDContadores.id;
      Button localButton = new Button(this);
      localButton.setBackgroundResource(2130837532);
      localButton.setOnClickListener(new OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          ContadoresActivity.this.EliminaContador(i);
        }
      });
      TableRow localTableRow = new TableRow(this);
      localTableRow.addView(localTextView1);
      localTableRow.addView(localTextView2);
      localTableRow.addView(localButton);
      this.TCo.addView(localTableRow);

      localTextView2.setTextColor(-16711936);
      return;
    }
  }
  
  private void EliminaContador(int paramInt)
  {
    SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
    new BDContadores().Elimina(localSQLiteDatabase, paramInt);
    this.accesoBD.CierraBD(localSQLiteDatabase);
    CargaContadores();
    this.mToast = Toast.makeText(this, getResources().getString(2131165322), 1);
    this.mToast.show();
  }
  
  private void NuevoContador()
  {
    startActivity(new Intent(this, ContadoresNuevoActivity.class));
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903042);
    this.TCo = ((TableLayout)findViewById(2131230747));
    ((Button)findViewById(2131230748)).setOnClickListener(new OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        ContadoresActivity.this.NuevoContador();
      }
    });
  }
  
  public void onResume()
  {
    super.onResume();
    CargaContadores();
  }
}


