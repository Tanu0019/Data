package com.mikki.dataoncount;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class ContadoresNuevoActivity
  extends Activity
{
  Button BCoGuardar;
  Spinner SCoDiaIni;
  Spinner SCoNum;
  Spinner SCoTipos;
  EditText TBCoMbNoti;
  TextView TVCoUnidades;
  CDIBD accesoBD;
  Toast mToast;

  @Override
  public SQLiteDatabase openOrCreateDatabase(String localSQLiteDatabase, int mode, SQLiteDatabase.CursorFactory factory) {
    return super.openOrCreateDatabase(localSQLiteDatabase, mode, factory);
  }

  private void CargaTipos()
  {
    String[] arrayOfString = new String[6];
    arrayOfString[0] = getResources().getString(2131165266);
    arrayOfString[1] = getResources().getString(2131165267);
    arrayOfString[2] = getResources().getString(2131165268);
    arrayOfString[3] = getResources().getString(2131165269);
    arrayOfString[4] = getResources().getString(2131165270);
    arrayOfString[5] = getResources().getString(2131165271);
    ArrayAdapter localArrayAdapter = new ArrayAdapter(this, 17367048, arrayOfString);
    localArrayAdapter.setDropDownViewResource(17367049);
    this.SCoTipos.setAdapter(localArrayAdapter);
    this.SCoTipos.setOnItemSelectedListener(new OnItemSelectedListener() {
      public void onItemSelected(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong) {
        switch (paramAnonymousInt) {
          default:
            return;
          case 0:
            ContadoresNuevoActivity.this.ConfiguraHabilitados(BDContadores.tipoDiario);
            return;
          case 1:
            ContadoresNuevoActivity.this.ConfiguraHabilitados(BDContadores.tipoSemanal);
            return;
          case 2:
            ContadoresNuevoActivity.this.ConfiguraHabilitados(BDContadores.tipoUltimaSemana);
            return;
          case 3:
            ContadoresNuevoActivity.this.ConfiguraHabilitados(BDContadores.tipoMensual);
            return;
          case 4:
            ContadoresNuevoActivity.this.ConfiguraHabilitados(BDContadores.tipoUltimoMes);
          case 5:
            ContadoresNuevoActivity.this.ConfiguraHabilitados(BDContadores.tipoTotal);
            return;
        }
      }

      public void onNothingSelected(AdapterView<?> paramAnonymousAdapterView) {
        ContadoresNuevoActivity.this.ConfiguraHabilitados(-1);
      }
    });
  }
  
  private void ConfiguraHabilitados(int paramInt)
  {
    if (paramInt == -1)
    {
      this.TVCoUnidades.setText("");
      this.SCoNum.setEnabled(false);
      this.SCoDiaIni.setEnabled(false);
      this.TBCoMbNoti.setEnabled(false);
      this.BCoGuardar.setEnabled(false);
    }
    do
    {

      if (paramInt == BDContadores.tipoDiario)
      {
        ArrayAdapter localArrayAdapter1 = new ArrayAdapter(this, 17367048, new String[] { "1", "2", "3", "4", "5", "6", "7" });
        localArrayAdapter1.setDropDownViewResource(17367049);
        this.SCoNum.setAdapter(localArrayAdapter1);
        ArrayAdapter localArrayAdapter2 = new ArrayAdapter(this, 17367048, new String[] { "0" });
        localArrayAdapter2.setDropDownViewResource(17367049);
        this.SCoDiaIni.setAdapter(localArrayAdapter2);
        this.TVCoUnidades.setText(getResources().getString(2131165291));
        this.SCoNum.setEnabled(true);
        this.SCoDiaIni.setEnabled(false);
        this.TBCoMbNoti.setEnabled(true);
        this.BCoGuardar.setEnabled(true);
        return;
      }
      if (paramInt == BDContadores.tipoSemanal)
      {
        ArrayAdapter localArrayAdapter3 = new ArrayAdapter(this, 17367048, new String[] { "1", "2", "3", "4" });
        localArrayAdapter3.setDropDownViewResource(17367049);
        this.SCoNum.setAdapter(localArrayAdapter3);
        String[] arrayOfString1 = new String[7];
        arrayOfString1[0] = getResources().getString(2131165278);
        arrayOfString1[1] = getResources().getString(2131165272);
        arrayOfString1[2] = getResources().getString(2131165273);
        arrayOfString1[3] = getResources().getString(2131165274);
        arrayOfString1[4] = getResources().getString(2131165275);
        arrayOfString1[5] = getResources().getString(2131165276);
        arrayOfString1[6] = getResources().getString(2131165277);
        ArrayAdapter localArrayAdapter4 = new ArrayAdapter(this, 17367048, arrayOfString1);
        localArrayAdapter4.setDropDownViewResource(17367049);
        this.SCoDiaIni.setAdapter(localArrayAdapter4);
        this.TVCoUnidades.setText(getResources().getString(2131165292));
        this.SCoNum.setEnabled(true);
        this.SCoDiaIni.setEnabled(true);
        this.TBCoMbNoti.setEnabled(true);
        this.BCoGuardar.setEnabled(true);
        return;
      }
      if (paramInt == BDContadores.tipoUltimaSemana)
      {
        ArrayAdapter localArrayAdapter5 = new ArrayAdapter(this, 17367048, new String[] { "1", "2", "3", "4" });
        localArrayAdapter5.setDropDownViewResource(17367049);
        this.SCoNum.setAdapter(localArrayAdapter5);
        ArrayAdapter localArrayAdapter6 = new ArrayAdapter(this, 17367048, new String[] { "0" });
        localArrayAdapter6.setDropDownViewResource(17367049);
        this.SCoDiaIni.setAdapter(localArrayAdapter6);
        this.TVCoUnidades.setText(getResources().getString(2131165292));
        this.SCoNum.setEnabled(true);
        this.SCoDiaIni.setEnabled(false);
        this.TBCoMbNoti.setEnabled(true);
        this.BCoGuardar.setEnabled(true);
        return;
      }
      if (paramInt == BDContadores.tipoMensual)
      {
        ArrayAdapter localArrayAdapter7 = new ArrayAdapter(this, 17367048, new String[] { "1", "2", "3" });
        localArrayAdapter7.setDropDownViewResource(17367049);
        this.SCoNum.setAdapter(localArrayAdapter7);
        String[] arrayOfString2 = new String[31];
        for (int i = 1;; i++)
        {
          if (i > 31)
          {
            ArrayAdapter localArrayAdapter8 = new ArrayAdapter(this, 17367048, arrayOfString2);
            localArrayAdapter8.setDropDownViewResource(17367049);
            this.SCoDiaIni.setAdapter(localArrayAdapter8);
            this.TVCoUnidades.setText(getResources().getString(2131165293));
            this.SCoNum.setEnabled(true);
            this.SCoDiaIni.setEnabled(true);
            this.TBCoMbNoti.setEnabled(true);
            this.BCoGuardar.setEnabled(true);
            return;
          }
          arrayOfString2[(i - 1)] = Integer.toString(i);
        }
      }
      if (paramInt == BDContadores.tipoUltimoMes)
      {
        ArrayAdapter localArrayAdapter9 = new ArrayAdapter(this, 17367048, new String[] { "1", "2", "3" });
        localArrayAdapter9.setDropDownViewResource(17367049);
        this.SCoNum.setAdapter(localArrayAdapter9);
        ArrayAdapter localArrayAdapter10 = new ArrayAdapter(this, 17367048, new String[] { "0" });
        localArrayAdapter10.setDropDownViewResource(17367049);
        this.SCoDiaIni.setAdapter(localArrayAdapter10);
        this.TVCoUnidades.setText(getResources().getString(2131165293));
        this.SCoNum.setEnabled(true);
        this.SCoDiaIni.setEnabled(false);
        this.TBCoMbNoti.setEnabled(true);
        this.BCoGuardar.setEnabled(true);
        return;
      }
    } while (paramInt != BDContadores.tipoTotal);
    ArrayAdapter localArrayAdapter11 = new ArrayAdapter(this, 17367048, new String[] { "0" });
    localArrayAdapter11.setDropDownViewResource(17367049);
    this.SCoNum.setAdapter(localArrayAdapter11);
    ArrayAdapter localArrayAdapter12 = new ArrayAdapter(this, 17367048, new String[] { "0" });
    localArrayAdapter12.setDropDownViewResource(17367049);
    this.SCoDiaIni.setAdapter(localArrayAdapter12);
    this.SCoNum.setEnabled(false);
    this.SCoDiaIni.setEnabled(false);
    this.TBCoMbNoti.setEnabled(true);
    this.BCoGuardar.setEnabled(true);
  }
  
  private void GuardarContador()
  {
    for (;;)
    {
      int i = 0;
      int k = 0;
      SQLiteDatabase localSQLiteDatabase = null;

     BDContadores localBDContadores = null; try
      {
        i = this.SCoTipos.getSelectedItemPosition();
        int j = RevisaMbNoti();
        if (j == -1)
        {
          this.mToast = Toast.makeText(this, getResources().getString(2131165324), 1);
          this.mToast.show();
          return;
        }
        if (this.accesoBD == null) {
          this.accesoBD = new CDIBD(this, null, ConsumoDatosInternetActivity.versionBD);
        }
        localSQLiteDatabase = this.accesoBD.AbreBD();
        k = 0;
        localBDContadores = new BDContadores();
        localBDContadores.num = (1 + this.SCoNum.getSelectedItemPosition());
        localBDContadores.diaIni = (1 + this.SCoDiaIni.getSelectedItemPosition());
        localBDContadores.mbNoti = j;
        localBDContadores.avisado = 0;
        localBDContadores.fechaSiguienteAviso = "20120101000000";
        if (i != 0) {
          continue;
        }
        localBDContadores.tipo = BDContadores.tipoDiario;
      }
      catch (Exception localException)
      {
        //int i;
        //SQLiteDatabase localSQLiteDatabase;
        //BDContadores localBDContadores;
        new Util().WriteLog(this, "Error 765: " + localException.getMessage());
        this.mToast = Toast.makeText(this, "Error al guardar contador", 1);
        this.mToast.show();
     // continue;
        if (i != 2) {
        //continue;
        localBDContadores.tipo = BDContadores.tipoUltimaSemana;
         //ontinue;
        if (i != 3) {
         //ontinue;
        }
        localBDContadores.tipo = BDContadores.tipoMensual;
        k = 0;
      //continue;
        if (i != 4) {
        //continue;
        }
        localBDContadores.tipo = BDContadores.tipoUltimoMes;
        k = 0;
    //  continue;
        if (i != 5) {
      //  continue;
        }
        localBDContadores.tipo = BDContadores.tipoTotal;
        k = 0;
      //continue;
        k = 1;
        continue;
      }
      if (k == 0)
      {
        localBDContadores.Inserta(localSQLiteDatabase);
        this.mToast = Toast.makeText(this, getResources().getString(2131165323), 1);
        this.mToast.show();
      }
      this.accesoBD.CierraBD(localSQLiteDatabase);
      finish();
     //eturn;
      if (i != 1) {
        continue;
      }
      localBDContadores.tipo = BDContadores.tipoSemanal;
      k = 0;
    }
  }
}
  private void MuestraAyuda()
  {
    Util.CreaAlertDialog(this, getResources().getString(2131165299), getResources().getString(2131165295), getResources().getString(2131165300), "");
  }
  
  private int RevisaMbNoti()
  {
    String str = this.TBCoMbNoti.getText().toString();
    try
    {
      int i = Integer.parseInt(str);
      int j = i;
      if ((j > 10000) || (j < 0)) {
        j = -1;
      }
      return j;
    }
    catch (Exception localException) {}
    return -1;
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903049);
    this.SCoTipos = ((Spinner)findViewById(2131230799));
    this.SCoNum = ((Spinner)findViewById(2131230801));
    this.SCoDiaIni = ((Spinner)findViewById(2131230804));
    this.TBCoMbNoti = ((EditText)findViewById(2131230807));
    this.TVCoUnidades = ((TextView)findViewById(2131230802));
    this.BCoGuardar = ((Button)findViewById(2131230809));
    this.BCoGuardar.setOnClickListener(new OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        ContadoresNuevoActivity.this.GuardarContador();
      }
    });
    ((Button)findViewById(2131230810)).setOnClickListener(new OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        ContadoresNuevoActivity.this.MuestraAyuda();
      }
    });
    ConfiguraHabilitados(-1);
    CargaTipos();
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\ContadoresNuevoActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */