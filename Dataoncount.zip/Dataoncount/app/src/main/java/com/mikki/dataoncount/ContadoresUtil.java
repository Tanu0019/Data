package com.mikki.dataoncount;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class ContadoresUtil
{
  public static String DiaSemana(int paramInt, Context paramContext) {
    switch (paramInt) {
      default:
        return "";
      case 1:
        return paramContext.getResources().getString(2131165285);
      case 2:
        return paramContext.getResources().getString(2131165279);
      case 3:
        return paramContext.getResources().getString(2131165280);
      case 4:
        return paramContext.getResources().getString(2131165281);
      case 5:
        return paramContext.getResources().getString(2131165282);
      case 6:
        return paramContext.getResources().getString(2131165283);
      case 7:
        return paramContext.getResources().getString(2131165284);
    }
  }
  
  public String CalculaSiguienteAviso(int paramInt)
  {
    Calendar localCalendar = Calendar.getInstance();
    GregorianCalendar localGregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    if (paramInt == BDContadores.tipoDiario)
    {
      localCalendar.add(5, 1);
      localGregorianCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 0, 0, 0);
    }
    for (;;)
    {
       Util.FormatoFecha(localGregorianCalendar);
      if (paramInt == BDContadores.tipoSemanal)
      {
        localCalendar.add(5, 7);
        localGregorianCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 0, 0, 0);
      }
      else if (paramInt == BDContadores.tipoUltimaSemana)
      {
        localCalendar.add(5, 1);
        localGregorianCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 12, 0, 0);
      }
      else if (paramInt == BDContadores.tipoMensual)
      {
        localCalendar.add(2, 1);
        localGregorianCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 0, 0, 0);
      }
      else if (paramInt == BDContadores.tipoUltimoMes)
      {
        localCalendar.add(5, 1);
        localGregorianCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 12, 0, 0);
      }
      else if (paramInt == BDContadores.tipoTotal)
      {
        localCalendar.add(1, 1);
        localGregorianCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 0, 0, 0);
      }
    }
  }
  
  public Double CalculaUnContador(Calendar paramCalendar, BDContadores paramBDContadores, Context paramContext, SQLiteDatabase paramSQLiteDatabase)
  {
    Double.valueOf(0.0D);
    return Double.valueOf(Double.valueOf(new Trafico().SumaBytes(new Estadisticas().SeleccionaEntreFechas(paramSQLiteDatabase, paramCalendar, Calendar.getInstance()), paramContext, "Estadisticas").doubleValue() / 1024.0D).doubleValue() / 1024.0D);
  }
  
  public String DescripcionContador(BDContadores paramBDContadores, Calendar paramCalendar, Context paramContext)
  {
    String str = "";
    if (paramBDContadores.tipo == BDContadores.tipoDiario) {
      str = paramContext.getResources().getString(2131165266) + " (" + Integer.toString(paramBDContadores.num) + ") " + Util.FormatoFechaBonito(paramCalendar) + " \n";
    }
    for (;;)
    {
      if (paramBDContadores.mbNoti > 0) {
        str = str + paramContext.getResources().getString(2131165325) + " " + Integer.toString(paramBDContadores.mbNoti);
      }
      //return str;
      if (paramBDContadores.tipo == BDContadores.tipoSemanal) {
        str = paramContext.getResources().getString(2131165267) + " (" + Integer.toString(paramBDContadores.num) + ") " + Util.FormatoFechaBonito(paramCalendar) + " \n" + paramContext.getResources().getString(2131165326) + " " + DiaSemana(paramBDContadores.diaIni, paramContext) + " ";
      } else if (paramBDContadores.tipo == BDContadores.tipoUltimaSemana) {
        str = paramContext.getResources().getString(2131165268) + " (" + Integer.toString(paramBDContadores.num) + ") " + Util.FormatoFechaBonito(paramCalendar) + " \n";
      } else if (paramBDContadores.tipo == BDContadores.tipoMensual) {
        str = paramContext.getResources().getString(2131165269) + " (" + Integer.toString(paramBDContadores.num) + ") " + Util.FormatoFechaBonito(paramCalendar) + " \n" + paramContext.getResources().getString(2131165326) + " " + Integer.toString(paramBDContadores.diaIni) + " ";
      } else if (paramBDContadores.tipo == BDContadores.tipoUltimoMes) {
        str = paramContext.getResources().getString(2131165270) + " (" + Integer.toString(paramBDContadores.num) + ") " + Util.FormatoFechaBonito(paramCalendar) + " \n";
      } else if (paramBDContadores.tipo == BDContadores.tipoTotal) {
        str = paramContext.getResources().getString(2131165271) + " (" + Integer.toString(paramBDContadores.num) + ") " + Util.FormatoFechaBonito(paramCalendar) + " \n";
      }
    }
  }
  
  public String DescripcionContadorCorta(BDContadores paramBDContadores, Context paramContext)
  {
    String str = "";
    if (paramBDContadores.tipo == BDContadores.tipoDiario) {
      str = paramContext.getResources().getString(2131165266);
    }
    for (;;)
    {
      if (paramBDContadores.mbNoti > 0) {
        str = str + " " + Integer.toString(paramBDContadores.mbNoti) + " Mb";
      }
      //return str;
      if (paramBDContadores.tipo == BDContadores.tipoSemanal) {
        str = paramContext.getResources().getString(2131165267);
      } else if (paramBDContadores.tipo == BDContadores.tipoUltimaSemana) {
        str = paramContext.getResources().getString(2131165268);
      } else if (paramBDContadores.tipo == BDContadores.tipoMensual) {
        str = paramContext.getResources().getString(2131165269);
      } else if (paramBDContadores.tipo == BDContadores.tipoUltimoMes) {
        str = paramContext.getResources().getString(2131165270);
      } else if (paramBDContadores.tipo == BDContadores.tipoTotal) {
        str = paramContext.getResources().getString(2131165271);
      }
    }
  }
  
  public Calendar Desde(BDContadores paramBDContadores)
  {
    Calendar localCalendar1 = Calendar.getInstance();
    Calendar localCalendar2 = Calendar.getInstance();
    if (paramBDContadores.tipo == BDContadores.tipoDiario) {
      localCalendar1.add(5, -1 * (-1 + paramBDContadores.num));
    }
    do
    {
      for (;;)
      {
        //return localCalendar1;
        if (paramBDContadores.tipo == BDContadores.tipoSemanal)
        {
          if (paramBDContadores.num > 1) {
            localCalendar1.add(5, -1 * (7 * (-1 + paramBDContadores.num)));
          }
          int j = localCalendar2.get(7);
          if (j > paramBDContadores.diaIni)
          {
            localCalendar1.add(5, -1 * (j - paramBDContadores.diaIni));
            return localCalendar1;
          }
          if (j < paramBDContadores.diaIni)
          {
            localCalendar1.add(5, -7 + (paramBDContadores.diaIni - j));
            return localCalendar1;
          }
        }
        else
        {
          if (paramBDContadores.tipo == BDContadores.tipoUltimaSemana)
          {
            localCalendar1.add(5, -1 * (7 * paramBDContadores.num));
            return localCalendar1;
          }
          if (paramBDContadores.tipo != BDContadores.tipoMensual) {
            break;
          }
          int i = localCalendar2.get(5);
          if (i > paramBDContadores.diaIni) {
            localCalendar1.set(localCalendar2.get(1), localCalendar2.get(2), paramBDContadores.diaIni, 0, 0, 0);
          }
          while (paramBDContadores.num > 1)
          {
            localCalendar1.add(2, -1 * (-1 + paramBDContadores.num));
            //return localCalendar1;
            if (i < paramBDContadores.diaIni)
            {
              localCalendar1.set(localCalendar2.get(1), localCalendar2.get(2), paramBDContadores.diaIni, 0, 0, 0);
              localCalendar1.add(2, -1);
            }
          }
        }
      }
      if (paramBDContadores.tipo == BDContadores.tipoUltimoMes)
      {
        localCalendar1.add(2, -1 * paramBDContadores.num);
        return localCalendar1;
      }
    } while (paramBDContadores.tipo != BDContadores.tipoTotal);
    localCalendar1.add(1, -1);
    return localCalendar1;
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\ContadoresUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */