package com.mikki.dataoncount;

import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class Estadisticas
{
  public static final String Campos = " (id integer primary key autoincrement, fecha string, movilRX long, movilTX long, totalRX long, totalTX long) ";
  public static final String TableName = "Estadisticas";
  public static final int columnaRx = 2;
  public static final int columnaTx = 3;
  public static final String sqlCreate = "CREATE TABLE Estadisticas (id integer primary key autoincrement, fecha string, movilRX long, movilTX long, totalRX long, totalTX long) ";
  public static final String sqlCreateIfNotExists = "CREATE TABLE if not exists Estadisticas (id integer primary key autoincrement, fecha string, movilRX long, movilTX long, totalRX long, totalTX long) ";
  public static final String sqlDeleteTable = "DROP TABLE IF EXISTS Estadisticas";
  public String fecha;
  public long movilRX;
  public long movilTX;
  public long totalRX;
  public long totalTX;
  
  public void Inserta(SQLiteDatabase paramSQLiteDatabase, Context paramContext)
  {
    String str1 = "";
    String str2 = "";
    try
    {
      Calendar localCalendar = Calendar.getInstance();
      GregorianCalendar localGregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
      int i = Integer.parseInt(paramContext.getResources().getString(2131165221));
      localGregorianCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 0, 0, 0);
      localGregorianCalendar.add(2, i * -1);
      str1 = "DELETE FROM Estadisticas WHERE fecha < '" + Util.FormatoFecha(localGregorianCalendar) + "'";
      paramSQLiteDatabase.execSQL(str1);
      str2 = "INSERT INTO Estadisticas (fecha, movilRX, movilTX, totalRX, totalTX) VALUES  (" + this.fecha + ", " + this.movilRX + ", " + this.movilTX + " ," + this.totalRX + "," + this.totalTX + ")";
      paramSQLiteDatabase.execSQL(str2);
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog("Error 3355 (inserta estadisticas): " + localException.getMessage() + " sqlIns: " + str2 + " sqlDel: " + str1);
    }
  }
  
  public Cursor SeleccionaDesdeDia(SQLiteDatabase paramSQLiteDatabase, Calendar paramCalendar)
  {
    GregorianCalendar localGregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    localGregorianCalendar.set(paramCalendar.get(1), paramCalendar.get(2), paramCalendar.get(5), 0, 0, 0);
    String[] arrayOfString = new String[1];
    arrayOfString[0] = Util.FormatoFecha(localGregorianCalendar);
    return paramSQLiteDatabase.rawQuery(" SELECT id, fecha, movilRX, movilTX, totalRX, totalTX FROM Estadisticas WHERE fecha>? ORDER BY fecha", arrayOfString);
  }
  
  public Cursor SeleccionaEntreFechas(SQLiteDatabase paramSQLiteDatabase, Calendar paramCalendar1, Calendar paramCalendar2)
  {
    paramCalendar1.set(paramCalendar1.get(1), paramCalendar1.get(2), paramCalendar1.get(5), 0, 0, 0);
    paramCalendar2.set(paramCalendar2.get(1), paramCalendar2.get(2), paramCalendar2.get(5), 23, 59, 59);
    String[] arrayOfString = new String[2];
    arrayOfString[0] = Util.FormatoFecha(paramCalendar1);
    arrayOfString[1] = Util.FormatoFecha(paramCalendar2);
    return paramSQLiteDatabase.rawQuery(" SELECT id, fecha, movilRX, movilTX, totalRX, totalTX FROM Estadisticas WHERE fecha>=? AND fecha<=? ORDER BY fecha", arrayOfString);
  }
  
  public String SeleccionaPrimeraFecha(SQLiteDatabase paramSQLiteDatabase)
  {
    String str = "";
    Cursor localCursor = paramSQLiteDatabase.rawQuery(" SELECT id, fecha FROM Estadisticas ORDER BY fecha asc", new String[0]);
    if (localCursor.moveToFirst()) {
      str = localCursor.getString(1);
    }
    localCursor.close();
    return str;
  }
  
  public Cursor SeleccionaUnDia(SQLiteDatabase paramSQLiteDatabase, Calendar paramCalendar)
  {
    GregorianCalendar localGregorianCalendar1 = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    localGregorianCalendar1.set(paramCalendar.get(1), paramCalendar.get(2), paramCalendar.get(5), 0, 0, 0);
    GregorianCalendar localGregorianCalendar2 = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    localGregorianCalendar2.set(paramCalendar.get(1), paramCalendar.get(2), paramCalendar.get(5), 23, 59, 59);
    String[] arrayOfString = new String[2];
    arrayOfString[0] = Util.FormatoFecha(localGregorianCalendar1);
    arrayOfString[1] = Util.FormatoFecha(localGregorianCalendar2);
    return paramSQLiteDatabase.rawQuery(" SELECT id, fecha, movilRX, movilTX, totalRX, totalTX FROM Estadisticas WHERE fecha>=? AND fecha<=? ORDER BY fecha", arrayOfString);
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\Estadisticas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */