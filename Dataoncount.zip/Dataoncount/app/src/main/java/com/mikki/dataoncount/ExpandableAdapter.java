package com.mikki.dataoncount;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

public class ExpandableAdapter
  extends BaseExpandableListAdapter
{
  private String[][] mContents;
  private Context mContext;
  private String[] mTitles;
  
  public ExpandableAdapter(Context paramContext, String[] paramArrayOfString, String[][] paramArrayOfString1)
  {
    if (paramArrayOfString.length != paramArrayOfString1.length) {
      throw new IllegalArgumentException("Títulos y contenido con tamaño diferentes");
    }
    this.mContext = paramContext;
    this.mContents = paramArrayOfString1;
    this.mTitles = paramArrayOfString;
  }
  
  public String getChild(int paramInt1, int paramInt2)
  {
    return this.mContents[paramInt1][paramInt2];
  }
  
  public long getChildId(int paramInt1, int paramInt2)
  {
    return 0L;
  }
  
  public View getChildView(int paramInt1, int paramInt2, boolean paramBoolean, View paramView, ViewGroup paramViewGroup)
  {
    TextView localTextView = (TextView)paramView;
    if (localTextView == null) {
      localTextView = new TextView(this.mContext);
    }
    localTextView.setText(this.mContents[paramInt1][paramInt2]);
    return localTextView;
  }
  
  public View getChildView2(int paramInt1, int paramInt2, boolean paramBoolean, View paramView, ViewGroup paramViewGroup)
  {
    String str = getChild(paramInt1, paramInt2);
    if (paramView == null) {
      paramView = ((LayoutInflater)this.mContext.getSystemService("layout_inflater")).inflate(2130903046, null);
    }
    ((TextView)paramView.findViewById(2131230756)).setText(str);
    return paramView;
  }
  
  public int getChildrenCount(int paramInt)
  {
    return this.mContents[paramInt].length;
  }
  
  public String[] getGroup(int paramInt)
  {
    return this.mContents[paramInt];
  }
  
  public int getGroupCount()
  {
    return this.mContents.length;
  }
  
  public long getGroupId(int paramInt)
  {
    return 0L;
  }
  
  public View getGroupView(int paramInt, boolean paramBoolean, View paramView, ViewGroup paramViewGroup)
  {
    TextView localTextView = (TextView)paramView;
    if (localTextView == null) {
      localTextView = new TextView(this.mContext);
    }
    localTextView.setTextSize(17.0F);
    localTextView.setTextColor(-16776961);
    localTextView.setText(this.mTitles[paramInt]);
    return localTextView;
  }
  
  public View getGroupView2(int paramInt, boolean paramBoolean, View paramView, ViewGroup paramViewGroup)
  {
    String str = this.mTitles[paramInt];
    if (paramView == null) {
      paramView = ((LayoutInflater)this.mContext.getSystemService("layout_inflater")).inflate(2130903045, null);
    }
    ((TextView)paramView.findViewById(2131230755)).setText(str);
    return paramView;
  }
  
  public boolean hasStableIds()
  {
    return false;
  }
  
  public boolean isChildSelectable(int paramInt1, int paramInt2)
  {
    return true;
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\ExpandableAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */