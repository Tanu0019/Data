package com.mikki.dataoncount;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class HistoricoActivity
  extends Activity
{
  Button BHiDerecha;
  Button BHiIzquierda;
  int NumPorPagina;
  int UltimosFi;
  int UltimosIni;
  CDIBD accesoBD;
  Configuracion confActual;
  Toast mToast;
  
  private void ActualizaApps()
  {
    try
    {
      if (this.accesoBD == null) {
        this.accesoBD = new CDIBD(this, null, ConsumoDatosInternetActivity.versionBD);
      }
      SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
      this.confActual = new Configuracion();
      this.confActual.CargaConfiguracion(localSQLiteDatabase, this);
      this.UltimosFi = this.confActual.ultimosDias;
      this.UltimosIni = 0;
      this.NumPorPagina = this.confActual.ultimosDias;
      String str1 = new Estadisticas().SeleccionaPrimeraFecha(localSQLiteDatabase);
      Calendar localCalendar = null;
      if (str1 != "") {
        localCalendar = Util.FormatoFecha(str1);
      }
      String str2;
      for (Object localObject = getResources().getString(2131165328) + " " + localCalendar.getTime().toGMTString();; localObject = str2)
      {
        ((TextView)findViewById(2131230760)).setText(localObject + "\n" + getResources().getString(2131165329) + " " + Integer.toString(this.confActual.ultimosDias) + " " + getResources().getString(2131165291));
        Consulta(localSQLiteDatabase);
        this.accesoBD.CierraBD(localSQLiteDatabase);
        //return;
        str2 = getResources().getString(2131165327);
      }
      //return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(this, "Error 1824: " + localException.getMessage());
      this.mToast = Toast.makeText(this, "Error al actualizar histórico", 1);
      this.mToast.show();
    }
  }
  
  private void CargaListas(String[] paramArrayOfString, String[][] paramArrayOfString1)
  {
    try
    {
      ExpandableListView localExpandableListView = (ExpandableListView)findViewById(2131230765);
      localExpandableListView.setGroupIndicator(null);
      localExpandableListView.setChildIndicator(null);
      localExpandableListView.setAdapter(new ExpandableAdapter(this, paramArrayOfString, paramArrayOfString1));
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(this, "Error 678: " + localException.getMessage());
      this.mToast = Toast.makeText(this, "Error cargando lista de aplicaciones.", 1);
      this.mToast.show();
    }
  }
  
  private void Consulta(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      Trafico localTrafico = new Trafico();
      Estadisticas localEstadisticas = new Estadisticas();
      Aplicaciones localAplicaciones = new Aplicaciones();
      Double.valueOf(0.0D);
      String[] arrayOfString = new String[this.confActual.ultimosDias];
      String[][] arrayOfString1 = new String[this.confActual.ultimosDias][];
      Util localUtil = new Util();
      int i = this.UltimosIni;
      for (int j = 0;; j++)
      {
        if (i >= this.UltimosFi)
        {
          CargaListas(arrayOfString, arrayOfString1);
          return;
        }
        Calendar localCalendar = Calendar.getInstance();
        localCalendar.add(5, i * -1);
        Double localDouble = localTrafico.SumaBytes(localEstadisticas.SeleccionaUnDia(paramSQLiteDatabase, localCalendar), this, "Estadisticas");
        arrayOfString[j] = (Util.FormatoFechaBonito(localCalendar) + ": " + Util.ByteToMega(localDouble) + " Mb " + getResources().getString(2131165330));
        arrayOfString1[j] = localUtil.ArrayToStringCortoParaExpandible(localTrafico.SumaBytesPorAplicaciones(localAplicaciones.SeleccionaUnDia(paramSQLiteDatabase, localCalendar), this), Integer.valueOf(1000));
        i++;
      }
      //return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(this, "Error 777: " + localException.getMessage());
      this.mToast = Toast.makeText(this, "Error al consultar histórico", 1);
      this.mToast.show();
    }
  }
  
  private void Derecha()
  {
    this.UltimosFi += this.NumPorPagina;
    this.UltimosIni += this.NumPorPagina;
    Mueve();
  }
  
  private void Izquierda()
  {
    if (this.UltimosIni - this.NumPorPagina >= 0)
    {
      this.UltimosFi -= this.NumPorPagina;
      this.UltimosIni -= this.NumPorPagina;
      Mueve();
    }
  }
  
  private void Mueve()
  {
    SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
    Consulta(localSQLiteDatabase);
    this.accesoBD.CierraBD(localSQLiteDatabase);
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903047);
    this.BHiIzquierda = ((Button)findViewById(2131230763));
    this.BHiIzquierda.setOnClickListener(new OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        HistoricoActivity.this.Izquierda();
      }
    });
    this.BHiDerecha = ((Button)findViewById(2131230764));
    this.BHiDerecha.setOnClickListener(new OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        HistoricoActivity.this.Derecha();
      }
    });
    ActualizaApps();
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\HistoricoActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */