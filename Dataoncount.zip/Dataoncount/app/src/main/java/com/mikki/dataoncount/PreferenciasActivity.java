package com.mikki.dataoncount;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class PreferenciasActivity
  extends Activity {
    CheckBox CBGuardaLog;
    CheckBox CBNotificaciones;
    EditText ETDiaFactura;
    EditText ETMbContratados;
    EditText ETUltimosDias;
    TextView TVIni;
    CDIBD accesoBD;
    Toast mToast;

    private boolean DatosOK() {
        boolean bool = true;
        try {
            int k = Integer.parseInt(this.ETDiaFactura.getText().toString());
            if ((k < 1) || (k > 31)) {
                bool = false;
            }
        } catch (Exception localException1) {
            for (; ; ) {
            }
        }
        try {
            int j = Integer.parseInt(this.ETMbContratados.getText().toString());
            if ((j < 1) || (j > 10000)) {
                bool = false;
            }
        } catch (Exception localException2) {
            for (; ; ) {
                bool = false;
            }
        }
        try {
            int i = Integer.parseInt(this.ETUltimosDias.getText().toString());
            if ((i < 1) || (i > 31)) {
                bool = false;
            }
        } catch (Exception localException3) {
            for (; ; ) {
                bool = false;
            }
        }
        if (bool) {
            return bool;
        }
        this.mToast = Toast.makeText(this, getResources().getString(2131165337), 1);
        this.mToast.show();
        //return false;

        if (bool) {
            return bool;
        }
        this.mToast = Toast.makeText(this, getResources().getString(2131165336), 1);
        this.mToast.show();
        // return false;
        //return bool;


        if (!bool) {
            //return bool;
            this.mToast = Toast.makeText(this, getResources().getString(2131165335), 1);
            this.mToast.show();
            //return false;


            //return bool;
        }
        return bool;
    }



  private void DesactivaAlarma()
  {
    try
    {
      PendingIntent localPendingIntent = PendingIntent.getBroadcast(this, 0, new Intent(this, Alarma.class), 0);
      ((AlarmManager)getSystemService("alarm")).cancel(localPendingIntent);
      this.mToast = Toast.makeText(this, getResources().getString(2131165339), 1);
      this.mToast.show();
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(this, "Error 14: " + localException.getMessage());
      this.mToast = Toast.makeText(this, "Error al desactivar alarma", 1);
      this.mToast.show();
    }
  }
  
  private void GuardaConfiguracion()
  {
    if (!DatosOK()) {
      return;
    }
    SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
    Configuracion localConfiguracion = new Configuracion();
    localConfiguracion.diaFactura = Integer.parseInt(this.ETDiaFactura.getText().toString());
    localConfiguracion.mbContratados = Integer.parseInt(this.ETMbContratados.getText().toString());
    localConfiguracion.ultimosDias = Integer.parseInt(this.ETUltimosDias.getText().toString());
    if (this.CBNotificaciones.isChecked()) {}
    for (int i = 1;; i = 0)
    {
      localConfiguracion.notificaciones = i;
      boolean bool = this.CBGuardaLog.isChecked();
      int j = 0;
      if (bool) {
        j = 1;
      }
      localConfiguracion.guardaLog = j;
      localConfiguracion.frecuencia = Integer.parseInt(getResources().getString(2131165217));
      localConfiguracion.automatico = Integer.parseInt(getResources().getString(2131165214));
      localConfiguracion.InsertaConfiguracion(localSQLiteDatabase);
      this.accesoBD.CierraBD(localSQLiteDatabase);
      this.mToast = Toast.makeText(this, getResources().getString(2131165338), 1);
      this.mToast.show();
      return;
    }
  }
  
  private void Inicialitza()
  {
    boolean bool1 = true;
    if (this.accesoBD == null) {
      this.accesoBD = new CDIBD(this, null, ConsumoDatosInternetActivity.versionBD);
    }
    SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
    Configuracion localConfiguracion = new Configuracion();
    localConfiguracion.CargaConfiguracion(localSQLiteDatabase, this);
    PrimeraFecha(localSQLiteDatabase);
    this.ETDiaFactura.setText(Integer.toString(localConfiguracion.diaFactura));
    this.ETMbContratados.setText(Integer.toString(localConfiguracion.mbContratados));
    this.ETUltimosDias.setText(Integer.toString(localConfiguracion.ultimosDias));
    CheckBox localCheckBox1 = this.CBNotificaciones;
    boolean bool2;
    CheckBox localCheckBox2 = null;
    if (localConfiguracion.notificaciones > 0)
    {
      bool2 = bool1;
      localCheckBox1.setChecked(bool2);
      localCheckBox2 = this.CBGuardaLog;
      if (localConfiguracion.guardaLog <= 0) {
        //break;
      }
    }
    for (;;)
    {
      localCheckBox2.setChecked(bool1);
      this.accesoBD.CierraBD(localSQLiteDatabase);
      //return;
      bool2 = false;

      bool1 = false;
    }
  }
  
  private void PrimeraFecha(SQLiteDatabase paramSQLiteDatabase)
  {
    Estadisticas localEstadisticas = new Estadisticas();
    String str1 = localEstadisticas.SeleccionaPrimeraFecha(paramSQLiteDatabase);
    Calendar localCalendar2 = null;
    if (str1 != "") {
      localCalendar2 = Util.FormatoFecha(str1);
    }
    Calendar localCalendar1;
    for (String str2 = getResources().getString(2131165328) + " " + localCalendar2.getTime().toGMTString();; str2 = getResources().getString(2131165328) + " " + localCalendar1.getTime().toGMTString())
    {
      this.TVIni.setText(str2);
      //return;
      localCalendar1 = Util.FormatoFecha(localEstadisticas.SeleccionaPrimeraFecha(paramSQLiteDatabase));
    }
  }
  
  private void ResetContadores()
  {
    String str = "-";
    try
    {
      SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
      str = "DELETE FROM Aplicaciones";
      localSQLiteDatabase.execSQL(str);
      str = "DELETE FROM Estadisticas";
      localSQLiteDatabase.execSQL(str);
      this.accesoBD.CierraBD(localSQLiteDatabase);
      this.mToast = Toast.makeText(this, getResources().getString(2131165340), 1);
      this.mToast.show();
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(this, "Error 516: " + localException.getMessage() + " SQL: " + str);
      this.mToast = Toast.makeText(this, getResources().getString(2131165341), 1);
      this.mToast.show();
    }
  }
  /*
  private void VerNuevasFuncionesVersionPro()
  {
    startActivity(new Intent(this, VersionProActivity.class));
  }*/
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903050);
    this.TVIni = ((TextView)findViewById(2131230813));
    this.ETDiaFactura = ((EditText)findViewById(2131230815));
    this.ETMbContratados = ((EditText)findViewById(2131230817));
    this.ETUltimosDias = ((EditText)findViewById(2131230819));
    this.CBNotificaciones = ((CheckBox)findViewById(2131230821));
    this.CBGuardaLog = ((CheckBox)findViewById(2131230822));
    ((Button)findViewById(2131230823)).setOnClickListener(new OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        PreferenciasActivity.this.GuardaConfiguracion();
      }
    });
    this.CBNotificaciones.requestFocus();
    ((Button)findViewById(2131230824)).setOnClickListener(new OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        PreferenciasActivity.this.DesactivaAlarma();
      }
    });
    ((Button)findViewById(2131230825)).setOnClickListener(new OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        PreferenciasActivity.this.ResetContadores();
      }
    });
    Button localButton = (Button)findViewById(2131230826);
    if (ConsumoDatosInternetActivity.app == "PRO") {
      localButton.setVisibility(4);
    }
    for (;;)
    {
      Inicialitza();
      //return;
      localButton.setOnClickListener(new OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          //PreferenciasActivity.this.VerNuevasFuncionesVersionPro();
        }
      });
      localButton.setBackgroundColor(-16711681);
      localButton.setTextSize(16.0F);
      localButton.setTextColor(-12303292);
      localButton.setVisibility(0);
    }
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\PreferenciasActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */