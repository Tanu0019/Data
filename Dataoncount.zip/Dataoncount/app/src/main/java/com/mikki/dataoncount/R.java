package com.mikki.dataoncount;

public final class R
{
  public static final class attr
  {
    public static final int adSize = 2130771968;
    public static final int adSizes = 2130771969;
    public static final int adUnitId = 2130771970;
    public static final int buyButtonAppearance = 2130771992;
    public static final int buyButtonHeight = 2130771989;
    public static final int buyButtonText = 2130771991;
    public static final int buyButtonWidth = 2130771990;
    public static final int cameraBearing = 2130771972;
    public static final int cameraTargetLat = 2130771973;
    public static final int cameraTargetLng = 2130771974;
    public static final int cameraTilt = 2130771975;
    public static final int cameraZoom = 2130771976;
    public static final int environment = 2130771986;
    public static final int fragmentMode = 2130771988;
    public static final int fragmentStyle = 2130771987;
    public static final int mapType = 2130771971;
    public static final int maskedWalletDetailsBackground = 2130771995;
    public static final int maskedWalletDetailsButtonBackground = 2130771997;
    public static final int maskedWalletDetailsButtonTextAppearance = 2130771996;
    public static final int maskedWalletDetailsHeaderTextAppearance = 2130771994;
    public static final int maskedWalletDetailsLogoImageType = 2130771999;
    public static final int maskedWalletDetailsLogoTextColor = 2130771998;
    public static final int maskedWalletDetailsTextAppearance = 2130771993;
    public static final int theme = 2130771985;
    public static final int uiCompass = 2130771977;
    public static final int uiRotateGestures = 2130771978;
    public static final int uiScrollGestures = 2130771979;
    public static final int uiTiltGestures = 2130771980;
    public static final int uiZoomControls = 2130771981;
    public static final int uiZoomGestures = 2130771982;
    public static final int useViewLifecycle = 2130771983;
    public static final int zOrderOnTop = 2130771984;
  }
  
  public static final class color
  {
    public static final int Azul = 2131099671;
    public static final int Blanco = 2131099672;
    public static final int Gris = 2131099674;
    public static final int GrisClaro = 2131099675;
    public static final int Negro = 2131099673;
    public static final int Rojo = 2131099676;
    public static final int common_action_bar_splitter = 2131099657;
    public static final int common_signin_btn_dark_text_default = 2131099648;
    public static final int common_signin_btn_dark_text_disabled = 2131099650;
    public static final int common_signin_btn_dark_text_focused = 2131099651;
    public static final int common_signin_btn_dark_text_pressed = 2131099649;
    public static final int common_signin_btn_default_background = 2131099656;
    public static final int common_signin_btn_light_text_default = 2131099652;
    public static final int common_signin_btn_light_text_disabled = 2131099654;
    public static final int common_signin_btn_light_text_focused = 2131099655;
    public static final int common_signin_btn_light_text_pressed = 2131099653;
    public static final int common_signin_btn_text_dark = 2131099678;
    public static final int common_signin_btn_text_light = 2131099679;
    public static final int transp = 2131099677;
    public static final int wallet_bright_foreground_disabled_holo_light = 2131099663;
    public static final int wallet_bright_foreground_holo_dark = 2131099658;
    public static final int wallet_bright_foreground_holo_light = 2131099664;
    public static final int wallet_dim_foreground_disabled_holo_dark = 2131099660;
    public static final int wallet_dim_foreground_holo_dark = 2131099659;
    public static final int wallet_dim_foreground_inverse_disabled_holo_dark = 2131099662;
    public static final int wallet_dim_foreground_inverse_holo_dark = 2131099661;
    public static final int wallet_highlighted_text_holo_dark = 2131099668;
    public static final int wallet_highlighted_text_holo_light = 2131099667;
    public static final int wallet_hint_foreground_holo_dark = 2131099666;
    public static final int wallet_hint_foreground_holo_light = 2131099665;
    public static final int wallet_holo_blue_light = 2131099669;
    public static final int wallet_link_text_light = 2131099670;
    public static final int wallet_primary_text_holo_light = 2131099680;
    public static final int wallet_secondary_text_holo_dark = 2131099681;
  }
  
  public static final class drawable
  {
    public static final int acerca = 2130837504;
    public static final int aplicaciones = 2130837505;
    public static final int common_signin_btn_icon_dark = 2130837506;
    public static final int common_signin_btn_icon_disabled_dark = 2130837507;
    public static final int common_signin_btn_icon_disabled_focus_dark = 2130837508;
    public static final int common_signin_btn_icon_disabled_focus_light = 2130837509;
    public static final int common_signin_btn_icon_disabled_light = 2130837510;
    public static final int common_signin_btn_icon_focus_dark = 2130837511;
    public static final int common_signin_btn_icon_focus_light = 2130837512;
    public static final int common_signin_btn_icon_light = 2130837513;
    public static final int common_signin_btn_icon_normal_dark = 2130837514;
    public static final int common_signin_btn_icon_normal_light = 2130837515;
    public static final int common_signin_btn_icon_pressed_dark = 2130837516;
    public static final int common_signin_btn_icon_pressed_light = 2130837517;
    public static final int common_signin_btn_text_dark = 2130837518;
    public static final int common_signin_btn_text_disabled_dark = 2130837519;
    public static final int common_signin_btn_text_disabled_focus_dark = 2130837520;
    public static final int common_signin_btn_text_disabled_focus_light = 2130837521;
    public static final int common_signin_btn_text_disabled_light = 2130837522;
    public static final int common_signin_btn_text_focus_dark = 2130837523;
    public static final int common_signin_btn_text_focus_light = 2130837524;
    public static final int common_signin_btn_text_light = 2130837525;
    public static final int common_signin_btn_text_normal_dark = 2130837526;
    public static final int common_signin_btn_text_normal_light = 2130837527;
    public static final int common_signin_btn_text_pressed_dark = 2130837528;
    public static final int common_signin_btn_text_pressed_light = 2130837529;
    public static final int contadores = 2130837530;
    public static final int contadores2 = 2130837531;
    public static final int delete = 2130837532;
    public static final int getit_large = 2130837533;
    public static final int historico = 2130837534;
    public static final int ic_launcher = 2130837535;
    public static final int ic_plusone_medium_off_client = 2130837536;
    public static final int ic_plusone_small_off_client = 2130837537;
    public static final int ic_plusone_standard_off_client = 2130837538;
    public static final int ic_plusone_tall_off_client = 2130837539;
    public static final int powered_by_google_dark = 2130837540;
    public static final int powered_by_google_light = 2130837541;
    public static final int preferecias = 2130837542;
    public static final int verpro = 2130837543;
  }
  
  public static final class id
  {
    public static final int BAyuda = 2131230810;
    public static final int BCoGuardar = 2131230809;
    public static final int BDesactiva = 2131230824;
    public static final int BGuardar = 2131230823;
    public static final int BHiDerecha = 2131230764;
    public static final int BHiIzquierda = 2131230763;
    public static final int BLink = 2131230834;
    public static final int BLink2 = 2131230836;
    public static final int BNuevoContador = 2131230748;
    public static final int BReset = 2131230825;
    public static final int BSQL = 2131230831;
    public static final int BVerNuevasFunciones = 2131230826;
    public static final int CBCreaFichero = 2131230829;
    public static final int CBGuardaLog = 2131230822;
    public static final int CBNotificaciones = 2131230821;
    public static final int CBUpdate = 2131230828;
    public static final int ETDiaFactura = 2131230815;
    public static final int ETFichero = 2131230830;
    public static final int ETMbContratados = 2131230817;
    public static final int ETSQL = 2131230827;
    public static final int ETUltimosDias = 2131230819;
    public static final int PBDias = 2131230773;
    public static final int PBMb = 2131230775;
    public static final int PBWiDiaFactura = 2131230838;
    public static final int PBWiMbConsumo = 2131230840;
    public static final int SCoDiaIni = 2131230804;
    public static final int SCoNum = 2131230801;
    public static final int SCoTipos = 2131230799;
    public static final int TBCoMbNoti = 2131230807;
    public static final int TCo = 2131230747;
    public static final int TVAcercaDe = 2131230741;
    public static final int TVAcercaDe2 = 2131230740;
    public static final int TVApTitulo = 2131230743;
    public static final int TVAplicaciones1 = 2131230744;
    public static final int TVAplicaciones2 = 2131230745;
    public static final int TVAppUltimos = 2131230793;
    public static final int TVApps = 2131230749;
    public static final int TVApps2 = 2131230750;
    public static final int TVAyer = 2131230782;
    public static final int TVAyer2 = 2131230783;
    public static final int TVCoAlarma = 2131230806;
    public static final int TVCoDiaInicial = 2131230803;
    public static final int TVCoMb = 2131230808;
    public static final int TVCoTipo = 2131230798;
    public static final int TVCoUltimos = 2131230800;
    public static final int TVCoUnidades = 2131230802;
    public static final int TVConfiguracion = 2131230812;
    public static final int TVContadores = 2131230746;
    public static final int TVDi1 = 2131230753;
    public static final int TVDi2 = 2131230754;
    public static final int TVDiTitulo = 2131230752;
    public static final int TVDiaFactura = 2131230814;
    public static final int TVDiaSemana1 = 2131230777;
    public static final int TVDiaSemana2 = 2131230781;
    public static final int TVDiaSemana3 = 2131230785;
    public static final int TVDialogo = 2131230751;
    public static final int TVDias = 2131230820;
    public static final int TVDiasDesdeUltimaFactura = 2131230772;
    public static final int TVHistorico = 2131230759;
    public static final int TVHistorico2 = 2131230760;
    public static final int TVHoy = 2131230778;
    public static final int TVHoy2 = 2131230779;
    public static final int TVHoyApps = 2131230789;
    public static final int TVIni = 2131230813;
    public static final int TVInstrucciones = 2131230742;
    public static final int TVMbConsumidos = 2131230774;
    public static final int TVMbContratados = 2131230816;
    public static final int TVMostrarUltimosDias = 2131230818;
    public static final int TVSQL = 2131230832;
    public static final int TVTitulo = 2131230771;
    public static final int TVUltimosDias = 2131230786;
    public static final int TVUltimosDias2 = 2131230787;
    public static final int TVVersionPro = 2131230833;
    public static final int TVVersionPro1 = 2131230835;
    public static final int TVWiDias = 2131230837;
    public static final int TVWiMegas = 2131230839;
    public static final int TextViewGrupo = 2131230755;
    public static final int TextViewHijo01 = 2131230756;
    public static final int TextViewHijo02 = 2131230757;
    public static final int TextViewHijo03 = 2131230758;
    public static final int adView = 2131230767;
    public static final int book_now = 2131230736;
    public static final int buyButton = 2131230730;
    public static final int buy_now = 2131230735;
    public static final int buy_with_google = 2131230734;
    public static final int classic = 2131230737;
    public static final int expandableListView1 = 2131230765;
    public static final int firstLayout = 2131230766;
    public static final int grayscale = 2131230738;
    public static final int holo_dark = 2131230725;
    public static final int holo_light = 2131230726;
    public static final int hybrid = 2131230724;
    public static final int linearLayout1 = 2131230811;
    public static final int mainLayout = 2131230768;
    public static final int match_parent = 2131230732;
    public static final int monochrome = 2131230739;
    public static final int none = 2131230720;
    public static final int normal = 2131230721;
    public static final int production = 2131230727;
    public static final int sandbox = 2131230728;
    public static final int satellite = 2131230722;
    public static final int selectionDetails = 2131230731;
    public static final int strict_sandbox = 2131230729;
    public static final int tableAppsHoy = 2131230791;
    public static final int tableAppsUltimos = 2131230795;
    public static final int tableContadores = 2131230776;
    public static final int tableLayout1 = 2131230761;
    public static final int tableLayout2 = 2131230797;
    public static final int tableRow1 = 2131230762;
    public static final int tableRow2 = 2131230780;
    public static final int tableRow3 = 2131230784;
    public static final int tableRow4 = 2131230805;
    public static final int tableRow5 = 2131230788;
    public static final int tableRow6 = 2131230790;
    public static final int tableRow7 = 2131230792;
    public static final int tableRow8 = 2131230794;
    public static final int tableRow9 = 2131230770;
    public static final int tableTitulo = 2131230769;
    public static final int terrain = 2131230723;
    public static final int textView3 = 2131230796;
    public static final int wrap_content = 2131230733;
  }
  
  public static final class integer
  {
    public static final int google_play_services_version = 2131296256;
  }
  
  public static final class layout
  {
    public static final int acercade = 2130903040;
    public static final int aplicaciones = 2130903041;
    public static final int contadores = 2130903042;
    public static final int dialogo = 2130903043;
    public static final int dialogo1 = 2130903044;
    public static final int expandablelistview_grupo = 2130903045;
    public static final int expandablelistview_hijo = 2130903046;
    public static final int historico = 2130903047;
    public static final int main = 2130903048;
    public static final int nuevocontador = 2130903049;
    public static final int preferencias = 2130903050;
    public static final int sqlform = 2130903051;
    public static final int versionpro = 2130903052;
    public static final int wi = 2130903053;
    public static final int wicopy = 2130903054;
  }
  
  public static final class string
  {
    public static final int AlarmaNOTIF_MSG1 = 2131165318;
    public static final int AlarmaNOTIF_MSG2 = 2131165319;
    public static final int AlarmaNOTIF_MSG22 = 2131165320;
    public static final int AlarmaTitulo = 2131165317;
    public static final int AplicacionesConConsumo = 2131165321;
    public static final int Ayuda = 2131165299;
    public static final int AyudaContadores = 2131165300;
    public static final int BCoGuardar = 2131165265;
    public static final int BDesactiva = 2131165226;
    public static final int BGuardar = 2131165225;
    public static final int BHiDerecha = 2131165296;
    public static final int BHiIzquierda = 2131165297;
    public static final int BLink = 2131165298;
    public static final int BNuevoContador = 2131165264;
    public static final int BPreferencias = 2131165229;
    public static final int BReset = 2131165227;
    public static final int BSQL = 2131165230;
    public static final int Bienvenida1 = 2131165315;
    public static final int Bienvenida2 = 2131165316;
    public static final int BienvenidaTitulo = 2131165314;
    public static final int CBAutomatico = 2131165245;
    public static final int CBCreaFichero = 2131165252;
    public static final int CBLog = 2131165261;
    public static final int CBNotificaciones = 2131165260;
    public static final int CBUpdate = 2131165251;
    public static final int Cargando = 2131165313;
    public static final int CoTipoDiario = 2131165266;
    public static final int CoTipoMensual = 2131165269;
    public static final int CoTipoSemanal = 2131165267;
    public static final int CoTipoTotal = 2131165271;
    public static final int CoTipoUltimaSemana = 2131165268;
    public static final int CoTipoUltimoMes = 2131165270;
    public static final int ContadorAlarma = 2131165325;
    public static final int ContadorEliminado = 2131165322;
    public static final int ContadorGuardado = 2131165323;
    public static final int ContadorIncorrecto = 2131165324;
    public static final int ContadorInicio = 2131165326;
    public static final int Contadores = 2131165294;
    public static final int Contadores2 = 2131165295;
    public static final int De_Of = 2131165311;
    public static final int Domingo = 2131165278;
    public static final int Domingo2 = 2131165285;
    public static final int ETFichero = 2131165253;
    public static final int ETSQL = 2131165244;
    public static final int ErrorCarga = 2131165312;
    public static final int HistoricoDatosDesde = 2131165328;
    public static final int HistoricoDetalle = 2131165329;
    public static final int HistoricoSinDatos = 2131165327;
    public static final int HistoricoVer = 2131165330;
    public static final int Jueves = 2131165275;
    public static final int Jueves2 = 2131165282;
    public static final int Lunes = 2131165272;
    public static final int Lunes2 = 2131165279;
    public static final int MNU_OPC1 = 2131165305;
    public static final int MNU_OPC2 = 2131165306;
    public static final int MNU_OPC3 = 2131165307;
    public static final int MNU_OPC4 = 2131165308;
    public static final int MNU_OPC5 = 2131165309;
    public static final int MNU_OPC6 = 2131165310;
    public static final int Martes = 2131165273;
    public static final int Martes2 = 2131165280;
    public static final int Miercoles = 2131165274;
    public static final int Miercoles2 = 2131165281;
    public static final int Nada = 2131165210;
    public static final int PreferenciasDesactivaConsultas = 2131165339;
    public static final int PreferenciasError1 = 2131165335;
    public static final int PreferenciasError2 = 2131165336;
    public static final int PreferenciasError3 = 2131165337;
    public static final int PreferenciasGuardadas = 2131165338;
    public static final int ResetERROR = 2131165341;
    public static final int ResetOK = 2131165340;
    public static final int Sabado = 2131165277;
    public static final int Sabado2 = 2131165284;
    public static final int SinDatos = 2131165223;
    public static final int TVAcercaDe = 2131165254;
    public static final int TVAcercaDe2 = 2131165262;
    public static final int TVAcercaDePRO = 2131165255;
    public static final int TVAppTotal = 2131165246;
    public static final int TVAppUltimos = 2131165247;
    public static final int TVApps = 2131165248;
    public static final int TVApps2 = 2131165249;
    public static final int TVAyer = 2131165243;
    public static final int TVCoAlarma = 2131165287;
    public static final int TVCoDiaInicial = 2131165289;
    public static final int TVCoMb = 2131165288;
    public static final int TVCoTipo = 2131165286;
    public static final int TVCoUltimos = 2131165290;
    public static final int TVConfiguracion = 2131165233;
    public static final int TVDiaFactura = 2131165232;
    public static final int TVDias = 2131165242;
    public static final int TVDiasDesdeUltimaFactura = 2131165235;
    public static final int TVFrecuencia = 2131165238;
    public static final int TVHistorico = 2131165263;
    public static final int TVHoy = 2131165239;
    public static final int TVHoyApps = 2131165250;
    public static final int TVInstrucciones = 2131165256;
    public static final int TVInstrucciones2 = 2131165257;
    public static final int TVListaProgramas = 2131165237;
    public static final int TVMbConsumidos = 2131165234;
    public static final int TVMbContratados = 2131165231;
    public static final int TVMostrarUltimosDias = 2131165241;
    public static final int TVPRO = 2131165304;
    public static final int TVProgramas = 2131165236;
    public static final int TVTitulo = 2131165258;
    public static final int TVUltimosDias = 2131165240;
    public static final int UtilAplicacionesSistema = 2131165332;
    public static final int UtilAplicacionesUsuario = 2131165331;
    public static final int UtilCerrar = 2131165333;
    public static final int VerMarket = 2131165303;
    public static final int VersionPRO = 2131165302;
    public static final int VersionPROCaracteristicas = 2131165301;
    public static final int VersionPROError = 2131165334;
    public static final int Viernes = 2131165276;
    public static final int Viernes2 = 2131165283;
    public static final int _Automatico = 2131165214;
    public static final int _Avisado = 2131165220;
    public static final int _BorrarMeses = 2131165221;
    public static final int _DiaFacturaDefecto = 2131165212;
    public static final int _FrecuenciaDefecto = 2131165217;
    public static final int _GuardaLog = 2131165216;
    public static final int _MbContratadosDefecto = 2131165213;
    public static final int _Notificaciones = 2131165215;
    public static final int _NumAplicacionesMostrar = 2131165219;
    public static final int _UltimosDias = 2131165218;
    public static final int _Zero = 2131165259;
    public static final int app_name = 2131165224;
    public static final int common_google_play_services_enable_button = 2131165195;
    public static final int common_google_play_services_enable_text = 2131165194;
    public static final int common_google_play_services_enable_title = 2131165193;
    public static final int common_google_play_services_error_notification_requested_by_msg = 2131165188;
    public static final int common_google_play_services_install_button = 2131165192;
    public static final int common_google_play_services_install_text_phone = 2131165190;
    public static final int common_google_play_services_install_text_tablet = 2131165191;
    public static final int common_google_play_services_install_title = 2131165189;
    public static final int common_google_play_services_invalid_account_text = 2131165201;
    public static final int common_google_play_services_invalid_account_title = 2131165200;
    public static final int common_google_play_services_needs_enabling_title = 2131165187;
    public static final int common_google_play_services_network_error_text = 2131165199;
    public static final int common_google_play_services_network_error_title = 2131165198;
    public static final int common_google_play_services_notification_needs_installation_title = 2131165185;
    public static final int common_google_play_services_notification_needs_update_title = 2131165186;
    public static final int common_google_play_services_notification_ticker = 2131165184;
    public static final int common_google_play_services_unknown_issue = 2131165202;
    public static final int common_google_play_services_unsupported_date_text = 2131165205;
    public static final int common_google_play_services_unsupported_text = 2131165204;
    public static final int common_google_play_services_unsupported_title = 2131165203;
    public static final int common_google_play_services_update_button = 2131165206;
    public static final int common_google_play_services_update_text = 2131165197;
    public static final int common_google_play_services_update_title = 2131165196;
    public static final int common_signin_button_text = 2131165207;
    public static final int common_signin_button_text_long = 2131165208;
    public static final int dias = 2131165291;
    public static final int hello = 2131165222;
    public static final int meses = 2131165293;
    public static final int old_BActualizar = 2131165228;
    public static final int semanas = 2131165292;
    public static final int tv3G = 2131165211;
    public static final int wallet_buy_button_place_holder = 2131165209;
  }
  
  public static final class style
  {
    public static final int Theme_IAPTheme = 2131034112;
    public static final int WalletFragmentDefaultButtonTextAppearance = 2131034115;
    public static final int WalletFragmentDefaultDetailsHeaderTextAppearance = 2131034114;
    public static final int WalletFragmentDefaultDetailsTextAppearance = 2131034113;
    public static final int WalletFragmentDefaultStyle = 2131034116;
  }
  
  public static final class styleable
  {
    public static final int[] AdsAttrs = { 2130771968, 2130771969, 2130771970 };
    public static final int AdsAttrs_adSize = 0;
    public static final int AdsAttrs_adSizes = 1;
    public static final int AdsAttrs_adUnitId = 2;
    public static final int[] MapAttrs = { 2130771971, 2130771972, 2130771973, 2130771974, 2130771975, 2130771976, 2130771977, 2130771978, 2130771979, 2130771980, 2130771981, 2130771982, 2130771983, 2130771984 };
    public static final int MapAttrs_cameraBearing = 1;
    public static final int MapAttrs_cameraTargetLat = 2;
    public static final int MapAttrs_cameraTargetLng = 3;
    public static final int MapAttrs_cameraTilt = 4;
    public static final int MapAttrs_cameraZoom = 5;
    public static final int MapAttrs_mapType = 0;
    public static final int MapAttrs_uiCompass = 6;
    public static final int MapAttrs_uiRotateGestures = 7;
    public static final int MapAttrs_uiScrollGestures = 8;
    public static final int MapAttrs_uiTiltGestures = 9;
    public static final int MapAttrs_uiZoomControls = 10;
    public static final int MapAttrs_uiZoomGestures = 11;
    public static final int MapAttrs_useViewLifecycle = 12;
    public static final int MapAttrs_zOrderOnTop = 13;
    public static final int[] WalletFragmentOptions = { 2130771985, 2130771986, 2130771987, 2130771988 };
    public static final int WalletFragmentOptions_environment = 1;
    public static final int WalletFragmentOptions_fragmentMode = 3;
    public static final int WalletFragmentOptions_fragmentStyle = 2;
    public static final int WalletFragmentOptions_theme = 0;
    public static final int[] WalletFragmentStyle = { 2130771989, 2130771990, 2130771991, 2130771992, 2130771993, 2130771994, 2130771995, 2130771996, 2130771997, 2130771998, 2130771999 };
    public static final int WalletFragmentStyle_buyButtonAppearance = 3;
    public static final int WalletFragmentStyle_buyButtonHeight = 0;
    public static final int WalletFragmentStyle_buyButtonText = 2;
    public static final int WalletFragmentStyle_buyButtonWidth = 1;
    public static final int WalletFragmentStyle_maskedWalletDetailsBackground = 6;
    public static final int WalletFragmentStyle_maskedWalletDetailsButtonBackground = 8;
    public static final int WalletFragmentStyle_maskedWalletDetailsButtonTextAppearance = 7;
    public static final int WalletFragmentStyle_maskedWalletDetailsHeaderTextAppearance = 5;
    public static final int WalletFragmentStyle_maskedWalletDetailsLogoImageType = 10;
    public static final int WalletFragmentStyle_maskedWalletDetailsLogoTextColor = 9;
    public static final int WalletFragmentStyle_maskedWalletDetailsTextAppearance = 4;
  }
  
  public static final class xml
  {
    public static final int bordershape = 2130968576;
    public static final int bordershapecabecera = 2130968577;
    public static final int tableshape = 2130968578;
    public static final int tv_shape = 2130968579;
    public static final int wiproperties = 2130968580;
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */