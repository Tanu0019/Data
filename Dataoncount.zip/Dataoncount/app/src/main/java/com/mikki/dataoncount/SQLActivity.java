package com.mikki.dataoncount;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import java.lang.reflect.Array;

public class SQLActivity
  extends Activity
{
  CDIBD accesoBD;
  
  private void EjecutaSQL()
  {
    for (;;)
    {
      int k = 0;
      String localObject = null;
      int j = 0;
      try
      {
        CheckBox localCheckBox = (CheckBox)findViewById(2131230828);
        EditText localEditText = (EditText)findViewById(2131230827);
        TextView localTextView = (TextView)findViewById(2131230832);
        localTextView.setText("");
        String str1 = localEditText.getText().toString();
        String str2 = str1 + "\n";
        SQLiteDatabase localSQLiteDatabase = this.accesoBD.AbreBD();
        if (localCheckBox.isChecked())
        {
          localSQLiteDatabase.execSQL(str1);
          this.accesoBD.CierraBD(localSQLiteDatabase);
          if (!((CheckBox)findViewById(2131230829)).isChecked()) {
            break;
          }
          String str3 = ((EditText)findViewById(2131230830)).getText().toString();
          new Util().WriteLog(str2, str3);
          return;
        }
        Cursor localCursor = localSQLiteDatabase.rawQuery(str1, new String[0]);
        int i = localCursor.getColumnCount();
        if (localCursor.moveToFirst())
        {
         // break;
          if (k >= i)
          {
            str2 = str2 + "\n" + (String)localObject;
            localTextView.append("\n" + (String)localObject);
            if (localCursor.moveToNext()) {
              break;
            }
          }
        }
        else
        {
          localCursor.close();
          continue;
        }
        try
        {
          String str6 = localObject + localCursor.getString(k) + " (s)/ ";
          localObject = str6;
        }
        catch (Exception localException2)
        {
          for (;;)
          {
            j = 0;
          }
        }
      }
      catch (Exception localException1)
      {
        new Util().WriteLog(this, "Error 5354: " + localException1.getMessage());
        return;
      }
      if (j == 0) {}
      Array localCursor = null;
      try
      {
        String str5 = localObject + localCursor.getInt(localCursor,k) + " (i)/ ";
        localObject = str5;
      }
      catch (Exception localException4)
      {
        for (;;)
        {
          j = 0;
        }
      }
      if (j == 0) {}
      try
      {
        String str4 = localObject + localCursor.getLong(localCursor,k) + " (l)/ ";
        localObject = str4;
        k++;
      }
      catch (Exception localException3)
      {
        for (;;)
        {
          j = 0;
        }
      }

      j = 1;
      k = 0;
    }
  }
  
  private void Inicialitza()
  {
    if (this.accesoBD == null) {
      this.accesoBD = new CDIBD(this, null, ConsumoDatosInternetActivity.versionBD);
    }
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903051);
    ((Button)findViewById(2131230831)).setOnClickListener(new OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        SQLActivity.this.EjecutaSQL();
      }
    });
    Inicialitza();
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\SQLActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */