package com.mikki.dataoncount;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.TrafficStats;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.TimeZone;

public class Trafico
{
  ConnectivityManager connectivity;
  NetworkInfo mobileInfo;
  NetworkInfo wifiInfo;
  
  public DatosTrafico ConsultaTrafico(Context paramContext)
  {
    DatosTrafico localDatosTrafico = new DatosTrafico();
    try
    {
      this.connectivity = ((ConnectivityManager)paramContext.getSystemService("connectivity"));
      this.wifiInfo = this.connectivity.getNetworkInfo(1);
      this.mobileInfo = this.connectivity.getNetworkInfo(0);
      if (TrafficStats.getMobileRxBytes() != -1L) {
        localDatosTrafico.rx = Long.valueOf(TrafficStats.getMobileRxBytes());
      }
      if (TrafficStats.getMobileTxBytes() != -1L) {
        localDatosTrafico.tx = Long.valueOf(TrafficStats.getMobileTxBytes());
      }
      if (TrafficStats.getTotalRxBytes() != -1L) {
        localDatosTrafico.totalrx = Long.valueOf(TrafficStats.getTotalRxBytes());
      }
      if (TrafficStats.getTotalTxBytes() != -1L) {
        localDatosTrafico.totaltx = Long.valueOf(TrafficStats.getTotalTxBytes());
      }
      return localDatosTrafico;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(paramContext, "Error 17: " + localException.getMessage());
    }
    return localDatosTrafico;
  }
  
  /* Error */
  public ArrayList<DatosTrafico> ConsultaTraficoAplicaciones(Context paramContext)
  {
    // Byte code:
    //   0: new 51	java/lang/Long
    //   3: dup
    //   4: lconst_0
    //   5: invokespecial 107	java/lang/Long:<init>	(J)V
    //   8: astore_2
    //   9: new 51	java/lang/Long
    //   12: dup
    //   13: lconst_0
    //   14: invokespecial 107	java/lang/Long:<init>	(J)V
    //   17: astore_3
    //   18: new 51	java/lang/Long
    //   21: dup
    //   22: lconst_0
    //   23: invokespecial 107	java/lang/Long:<init>	(J)V
    //   26: pop
    //   27: new 109	java/util/Hashtable
    //   30: dup
    //   31: invokespecial 110	java/util/Hashtable:<init>	()V
    //   34: astore 5
    //   36: new 112	java/util/ArrayList
    //   39: dup
    //   40: invokespecial 113	java/util/ArrayList:<init>	()V
    //   43: astore 6
    //   45: aload_1
    //   46: invokevirtual 117	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   49: astore 8
    //   51: aload 8
    //   53: sipush 128
    //   56: invokevirtual 123	android/content/pm/PackageManager:getInstalledApplications	(I)Ljava/util/List;
    //   59: invokeinterface 129 1 0
    //   64: astore 9
    //   66: aload_3
    //   67: astore 10
    //   69: aload_2
    //   70: astore 11
    //   72: aload 9
    //   74: invokeinterface 135 1 0
    //   79: ifne +19 -> 98
    //   82: aload 5
    //   84: invokestatic 139	com/si/datausage/Util:OrdenaHashTable	(Ljava/util/Hashtable;)Ljava/util/ArrayList;
    //   87: astore 24
    //   89: aload 10
    //   91: pop
    //   92: aload 11
    //   94: pop
    //   95: aload 24
    //   97: areturn
    //   98: aload 9
    //   100: invokeinterface 143 1 0
    //   105: checkcast 145	android/content/pm/ApplicationInfo
    //   108: astore 14
    //   110: aload 14
    //   112: getfield 149	android/content/pm/ApplicationInfo:uid	I
    //   115: istore 15
    //   117: new 51	java/lang/Long
    //   120: dup
    //   121: lconst_0
    //   122: invokespecial 107	java/lang/Long:<init>	(J)V
    //   125: astore 16
    //   127: new 51	java/lang/Long
    //   130: dup
    //   131: lconst_0
    //   132: invokespecial 107	java/lang/Long:<init>	(J)V
    //   135: astore 17
    //   137: aload 5
    //   139: iload 15
    //   141: invokestatic 154	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   144: invokevirtual 158	java/util/Hashtable:containsKey	(Ljava/lang/Object;)Z
    //   147: ifeq +80 -> 227
    //   150: aload 5
    //   152: iload 15
    //   154: invokestatic 154	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   157: invokevirtual 162	java/util/Hashtable:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   160: checkcast 19	com/si/datausage/Trafico$DatosTrafico
    //   163: astore 21
    //   165: aload 21
    //   167: new 82	java/lang/StringBuilder
    //   170: dup
    //   171: aload 21
    //   173: getfield 166	com/si/datausage/Trafico$DatosTrafico:name	Ljava/lang/String;
    //   176: invokestatic 171	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   179: invokespecial 87	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   182: ldc -83
    //   184: invokevirtual 95	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: aload 14
    //   189: aload 8
    //   191: invokevirtual 177	android/content/pm/ApplicationInfo:loadLabel	(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;
    //   194: invokevirtual 180	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   197: invokevirtual 98	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   200: putfield 166	com/si/datausage/Trafico$DatosTrafico:name	Ljava/lang/String;
    //   203: aload 5
    //   205: iload 15
    //   207: invokestatic 154	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   210: aload 21
    //   212: invokevirtual 184	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   215: pop
    //   216: aload 17
    //   218: astore 10
    //   220: aload 16
    //   222: astore 11
    //   224: goto -152 -> 72
    //   227: iload 15
    //   229: invokestatic 188	android/net/TrafficStats:getUidRxBytes	(I)J
    //   232: ldc2_w 48
    //   235: lcmp
    //   236: ifeq +13 -> 249
    //   239: iload 15
    //   241: invokestatic 188	android/net/TrafficStats:getUidRxBytes	(I)J
    //   244: invokestatic 55	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   247: astore 16
    //   249: iload 15
    //   251: invokestatic 191	android/net/TrafficStats:getUidTxBytes	(I)J
    //   254: ldc2_w 48
    //   257: lcmp
    //   258: ifeq +13 -> 271
    //   261: iload 15
    //   263: invokestatic 191	android/net/TrafficStats:getUidTxBytes	(I)J
    //   266: invokestatic 55	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   269: astore 17
    //   271: aload 17
    //   273: invokevirtual 194	java/lang/Long:longValue	()J
    //   276: aload 16
    //   278: invokevirtual 194	java/lang/Long:longValue	()J
    //   281: ladd
    //   282: invokestatic 55	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   285: astore 18
    //   287: aload 18
    //   289: invokevirtual 194	java/lang/Long:longValue	()J
    //   292: lconst_0
    //   293: lcmp
    //   294: ifle +41 -> 335
    //   297: new 19	com/si/datausage/Trafico$DatosTrafico
    //   300: dup
    //   301: aload_0
    //   302: aload 18
    //   304: aload 16
    //   306: aload 17
    //   308: aload 14
    //   310: aload 8
    //   312: invokevirtual 177	android/content/pm/ApplicationInfo:loadLabel	(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;
    //   315: iload 15
    //   317: invokespecial 197	com/si/datausage/Trafico$DatosTrafico:<init>	(Lcom/si/datausage/Trafico;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/CharSequence;I)V
    //   320: astore 19
    //   322: aload 5
    //   324: iload 15
    //   326: invokestatic 154	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   329: aload 19
    //   331: invokevirtual 184	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   334: pop
    //   335: aload 17
    //   337: astore 10
    //   339: aload 16
    //   341: astore 11
    //   343: goto -271 -> 72
    //   346: astore 7
    //   348: new 79	com/si/datausage/Util
    //   351: dup
    //   352: invokespecial 80	com/si/datausage/Util:<init>	()V
    //   355: aload_1
    //   356: new 82	java/lang/StringBuilder
    //   359: dup
    //   360: ldc -57
    //   362: invokespecial 87	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   365: aload 7
    //   367: invokevirtual 91	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   370: invokevirtual 95	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   373: invokevirtual 98	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   376: invokevirtual 102	com/si/datausage/Util:WriteLog	(Landroid/content/Context;Ljava/lang/String;)V
    //   379: aload 6
    //   381: areturn
    //   382: astore 7
    //   384: aload 10
    //   386: pop
    //   387: aload 11
    //   389: pop
    //   390: goto -42 -> 348
    //   393: astore 7
    //   395: aload 10
    //   397: pop
    //   398: goto -50 -> 348
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	401	0	this	Trafico
    //   0	401	1	paramContext	Context
    //   8	62	2	localLong1	Long
    //   17	50	3	localLong2	Long
    //   34	289	5	localHashtable	Hashtable
    //   43	337	6	localArrayList1	ArrayList
    //   346	20	7	localException1	Exception
    //   382	1	7	localException2	Exception
    //   393	1	7	localException3	Exception
    //   49	262	8	localPackageManager	PackageManager
    //   64	35	9	localIterator	Iterator
    //   67	329	10	localObject1	Object
    //   70	318	11	localObject2	Object
    //   108	201	14	localApplicationInfo	ApplicationInfo
    //   115	210	15	i	int
    //   125	215	16	localLong3	Long
    //   135	201	17	localLong4	Long
    //   285	18	18	localLong5	Long
    //   320	10	19	localDatosTrafico1	DatosTrafico
    //   163	48	21	localDatosTrafico2	DatosTrafico
    //   87	9	24	localArrayList2	ArrayList
    // Exception table:
    //   from	to	target	type
    //   45	66	346	java/lang/Exception
    //   137	216	346	java/lang/Exception
    //   227	249	346	java/lang/Exception
    //   249	271	346	java/lang/Exception
    //   271	335	346	java/lang/Exception
    //   72	89	382	java/lang/Exception
    //   98	127	382	java/lang/Exception
    //   127	137	393	java/lang/Exception
    return null;
  }
  
  public void ConsultaYGuarda(Context paramContext, String paramString, SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      String str1 = Util.FormatoFecha(Calendar.getInstance());
      DatosTrafico localDatosTrafico1 = ConsultaTrafico(paramContext);
      Estadisticas localEstadisticas = new Estadisticas();
      localEstadisticas.movilRX = localDatosTrafico1.rx.longValue();
      localEstadisticas.movilTX = localDatosTrafico1.tx.longValue();
      localEstadisticas.totalRX = localDatosTrafico1.totalrx.longValue();
      localEstadisticas.totalTX = localDatosTrafico1.totaltx.longValue();
      localEstadisticas.fecha = str1;
      localEstadisticas.Inserta(paramSQLiteDatabase, paramContext);
      int i = 0;
      ArrayList localArrayList = ConsultaTraficoAplicaciones(paramContext);
      int j = Integer.parseInt(paramContext.getResources().getString(2131165219));
      Iterator localIterator = localArrayList.iterator();
      if (!localIterator.hasNext()) {}
      for (;;)
      {
        Configuracion localConfiguracion = new Configuracion();
        localConfiguracion.CargaConfiguracion(paramSQLiteDatabase, paramContext);
        if (localConfiguracion.guardaLog <= 0) {
          return;
        }
        String str2 = paramString + "(" + localEstadisticas.fecha + ") : " + Long.toString(localDatosTrafico1.rx.longValue()) + " / " + Long.toString(localDatosTrafico1.tx.longValue()) + " / " + Long.toString(localDatosTrafico1.totalrx.longValue()) + " / " + Long.toString(localDatosTrafico1.totaltx.longValue());
        new Util().WriteLog(str2);
        //return;
        DatosTrafico localDatosTrafico2 = (DatosTrafico)localIterator.next();
        Aplicaciones localAplicaciones = new Aplicaciones();
        localAplicaciones.fecha = str1;
        localAplicaciones.movilRX = localDatosTrafico2.rx.longValue();
        localAplicaciones.movilTX = localDatosTrafico2.tx.longValue();
        localAplicaciones.uid = localDatosTrafico2.uid;
        localAplicaciones.appname = localDatosTrafico2.name;
        localAplicaciones.Inserta(paramSQLiteDatabase, paramContext);
        i++;
        if (i < j) {
          break;
        }
      }
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog("Error 12: " + paramString + " / " + localException.getMessage());
    }
  }
  
  public Double HayDesviacion(Context paramContext, SQLiteDatabase paramSQLiteDatabase)
  {
    Configuracion localConfiguracion = new Configuracion();
    localConfiguracion.CargaConfiguracion(paramSQLiteDatabase, paramContext);
    Calendar localCalendar = Calendar.getInstance();
    GregorianCalendar localGregorianCalendar1 = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    localGregorianCalendar1.set(localCalendar.get(1), localCalendar.get(2), localConfiguracion.diaFactura, 0, 0, 0);
    if (localCalendar.get(5) < localConfiguracion.diaFactura) {
      localGregorianCalendar1.add(2, -1);
    }
    Double localDouble1 = SumaBytes(new Estadisticas().SeleccionaDesdeDia(paramSQLiteDatabase, localGregorianCalendar1), paramContext, "Estadisticas");
    GregorianCalendar localGregorianCalendar2 = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    localGregorianCalendar2.set(localGregorianCalendar1.get(1), localGregorianCalendar1.get(2), localGregorianCalendar1.get(5), 0, 0, 0);
    localGregorianCalendar2.add(2, 1);
    long l1 = localGregorianCalendar1.getTime().getTime();
    Double localDouble2 = Double.valueOf(Math.floor((localGregorianCalendar2.getTime().getTime() - l1) / 8.64E7D));
    long l2 = localGregorianCalendar1.getTime().getTime();
    Double localDouble3 = Double.valueOf(1.0D + Double.valueOf(Math.floor((localCalendar.getTime().getTime() - l2) / 8.64E7D)).doubleValue());
    Double localDouble4 = Double.valueOf(1024.0D * localConfiguracion.mbContratados / localDouble2.doubleValue());
    Double localDouble5 = Double.valueOf(localDouble4.doubleValue() * localDouble3.doubleValue());
    Double localDouble6 = Double.valueOf(localDouble1.doubleValue() / 1024.0D);
    if (localDouble6.doubleValue() > localDouble5.doubleValue())
    {
      Double localDouble7 = Double.valueOf(Double.valueOf(localDouble6.doubleValue() - localDouble5.doubleValue()).doubleValue() / 1024.0D);
      if (localConfiguracion.guardaLog > 0)
      {
        String str = "NOTIFICA!\nDT " + localDouble2 + " /DH " + localDouble3 + " /kbDia " + localDouble4 + " /kbConsu " + localDouble6 + " /kbEsp " + localDouble5 + " /mbDesvio " + localDouble7 + "\n";
        new Util().WriteLog(str);
      }
      return localDouble7;
    }
    return Double.valueOf(0.0D);
  }
  
  public ArrayList<DatosTrafico> Rellena(Context paramContext, ArrayList<DatosTrafico> paramArrayList)
  {
    try
    {
      PackageManager localPackageManager = paramContext.getPackageManager();
      Iterator localIterator1 = localPackageManager.getInstalledApplications(128).iterator();
      label58:
      label150:
      for (;;)
      {
        if (!localIterator1.hasNext()) {
          return paramArrayList;
        }
        ApplicationInfo localApplicationInfo = (ApplicationInfo)localIterator1.next();
        int i = localApplicationInfo.uid;
        Iterator localIterator2 = paramArrayList.iterator();
        boolean bool = localIterator2.hasNext();
        int j = 0;
        if (!bool) {}
        for (;;)
        {
          if (j != 0) {
            break label150;
          }
          paramArrayList.add(new DatosTrafico(Long.valueOf(0L), Long.valueOf(0L), Long.valueOf(0L), localApplicationInfo.loadLabel(localPackageManager), i));
          if (paramArrayList.size() < 5) {
            break;
          }
         // return paramArrayList;
          int k = ((DatosTrafico)localIterator2.next()).uid;
          if (k != i) {
            break label58;
          }
          j = 1;
        }
      }
      return paramArrayList;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(paramContext, "Error 3328: " + localException.getMessage());
    }
    return paramArrayList;
  }
  
  public Double SumaBytes(Cursor paramCursor, Context paramContext, String paramString)
  {
    int i = 0;
    int j = 0;
    if (paramString == "Estadisticas")
    {
      i = 2;
      j = 3;
    }
    long l1;
    long l2;
    long l3;

    long l4;
    for (;;)
    {
      Long localLong = Long.valueOf(0L);
      try
      {
        if ((paramCursor.getCount() > 1) && (paramCursor.moveToFirst()))
        {
          l1 = paramCursor.getLong(i);
          l2 = paramCursor.getLong(j);
          l3 = 0L;
          l4 = 0L;
          if (paramCursor.moveToNext()) {
            break;
          }
          localLong = Long.valueOf(l3 + l4);
        }
        paramCursor.close();
      }
      catch (Exception localException)
      {
        for (;;)
        {

          new Util().WriteLog(paramContext, "Error 11: " + localException.getMessage());
        }
      }
      Double.valueOf(localLong.longValue());
      i = 0;
      j = 0;
      if (paramString == "Aplicaciones")
      {
        i = 4;
        j = 5;
      }
    }
    long l5 = paramCursor.getLong(i);

    long l6 = paramCursor.getLong(j);if ((l5 < l1) || (l6 < l2)) {
      l3 += l5;
    }
    for (l4 += l6;; l4 = l4 + l6 - l2)
    {
      l1 = l5;
      l2 = l6;
      break;
    }
    return null;
  }
  
  public ArrayList<DatosTrafico> SumaBytesPorAplicaciones(Cursor paramCursor, Context paramContext)
  {
    Hashtable localHashtable = new Hashtable();
    ArrayList localArrayList = new ArrayList();
    Long.valueOf(0L);
    for (;;)
    {
      int i = 0;
      Object localObject = null;
      long l3 = 0;
      long l4 = 0;
      long l5;
      long l6;
      int j;
      String str;
      try
      {
        long l1 = 0;

        long l2 = 0;
        if ((paramCursor.getCount() > 1) && (paramCursor.moveToFirst()))
        {
          l1 = paramCursor.getLong(4);
          l2 = paramCursor.getLong(5);
          i = paramCursor.getInt(2);
          localObject = paramCursor.getString(3);
          l3 = 0L;
          l4 = 0L;
          if (paramCursor.moveToNext()) {}
        }
        else
        {
          paramCursor.close();
           Util.OrdenaHashTable(localHashtable);
        }
        l5 = paramCursor.getLong(4);
        l6 = paramCursor.getLong(5);
        j = paramCursor.getInt(2);
        str = paramCursor.getString(3);
        if (j != i) {
          break;
        }
        if (l5 < l1) {
          break;
        }
        if (l6 >= l2) {
          break;
        }
      }
      catch (Exception localException)
      {
        DatosTrafico localDatosTrafico2;
        new Util().WriteLog(paramContext, "Error 811: " + localException.getMessage());
        return localArrayList;
      }
      long l1 = l5;
      long l2 = l6;
      Long localLong = Long.valueOf(l3 + l4);
      if (localHashtable.containsKey(Integer.valueOf(j)))
      {
        DatosTrafico localDatosTrafico2 = (DatosTrafico) localHashtable.get(Integer.valueOf(j));
        localDatosTrafico2.rx = Long.valueOf(l3);
        localDatosTrafico2.tx = Long.valueOf(l4);
        localDatosTrafico2.total = localLong;
        localHashtable.put(Integer.valueOf(j), localDatosTrafico2);
        //continue;
        //label288:
        l3 = l3 + l5 - l1;
        l4 = l4 + l6 - l2;
      }
      else
      {
        DatosTrafico localDatosTrafico1 = new DatosTrafico(localLong, Long.valueOf(l3), Long.valueOf(l4), (CharSequence)localObject, i);
        localHashtable.put(Integer.valueOf(i), localDatosTrafico1);
        //continue;
        label352:
        l1 = l5;
        l2 = l6;
        i = j;
        localObject = str;
        l3 = 0L;
        l4 = 0L;
        //continue;
        label377:
        l3 += l5;
        l4 += l6;
      }
    }
    return null;
  }
  
  public class DatosTrafico
  {
    public String name;
    public Long rx;
    public Long total;
    public Long totalrx;
    public Long totaltx;
    public Long tx;
    public int uid;
    
    public DatosTrafico()
    {
      Long localLong = Long.valueOf(0L);
      this.totaltx = localLong;
      this.totalrx = localLong;
      this.tx = localLong;
      this.rx = localLong;
      this.total = localLong;
      this.uid = 0;
      this.name = "";
    }
    
    public DatosTrafico(Long paramLong1, Long paramLong2, Long paramLong3, CharSequence paramCharSequence, int paramInt)
    {
      this.total = paramLong1;
      this.name = paramCharSequence.toString();
      this.rx = paramLong2;
      this.tx = paramLong3;
      this.uid = paramInt;
    }
    
    public DatosTrafico(Long paramLong1, Long paramLong2, Long paramLong3, Long paramLong4)
    {
      this.rx = paramLong3;
      this.tx = paramLong4;
      this.totalrx = paramLong1;
      this.totaltx = paramLong2;
    }
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\Trafico.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */