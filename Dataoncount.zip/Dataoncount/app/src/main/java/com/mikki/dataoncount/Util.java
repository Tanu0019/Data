package com.mikki.dataoncount;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
//import android.content.DialogInterface.OnClickListener;
//import android.content.res.Resources;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

public class Util
{
  public static int ValorMaximoRelativo = 10000;
  public static long temps1;
  public static long temps2;

  public static String ByteToMega(Double paramDouble)
  {
    return FormatoDecimal(Double.valueOf(Double.valueOf(paramDouble.doubleValue() / 1024.0D).doubleValue() / 1024.0D));
  }

  public static void CreaAlertDialog(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    View localView = ((LayoutInflater)paramContext.getSystemService("layout_inflater")).inflate(2130903044, null);
    ((TextView)localView.findViewById(2131230752)).setText(paramString2);
    ((TextView)localView.findViewById(2131230753)).setText(paramString3);
    ((TextView)localView.findViewById(2131230754)).setText(paramString4);
    String str = paramContext.getResources().getString(2131165333);
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(paramContext);
    localBuilder.setTitle(paramString1);
    localBuilder.setCancelable(false).setPositiveButton(str, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        paramAnonymousDialogInterface.cancel();
      }
    });
    localBuilder.setView(localView);
    localBuilder.create();
    localBuilder.show();
  }

  public static String FormatoDecimal(Double paramDouble)
  {
    return new DecimalFormat("#0.00").format(paramDouble);
  }

  public static String FormatoFecha(Calendar paramCalendar)
  {
    return IntToStr(paramCalendar.get(1), 4) + IntToStr(1 + paramCalendar.get(2), 2) + IntToStr(paramCalendar.get(5), 2) + IntToStr(paramCalendar.get(11), 2) + IntToStr(paramCalendar.get(12), 2) + IntToStr(paramCalendar.get(13), 2);
  }

  public static Calendar FormatoFecha(String paramString)
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.set(Integer.parseInt(paramString.substring(0, 4)), -1 + Integer.parseInt(paramString.substring(4, 6)), Integer.parseInt(paramString.substring(6, 8)), Integer.parseInt(paramString.substring(8, 10)), Integer.parseInt(paramString.substring(10, 12)), Integer.parseInt(paramString.substring(12, 14)));
    return localCalendar;
  }

  public static String FormatoFechaBonito(Calendar paramCalendar)
  {
    return IntToStr(paramCalendar.get(5), 2) + "-" + IntToStr(1 + paramCalendar.get(2), 2) + "-" + IntToStr(paramCalendar.get(1), 4);
  }

  private static String IntToStr(int paramInt1, int paramInt2)
  {
    for (String str = Integer.toString(paramInt1);; str = "0" + str) {
      if (str.length() >= paramInt2) {
        return str;
      }
    }
  }

  private String NowTimeToString()
  {
    Calendar localCalendar = Calendar.getInstance();
    return "\n" + IntToStr(localCalendar.get(5), 2) + "/" + IntToStr(localCalendar.get(11), 2) + ":" + IntToStr(localCalendar.get(12), 2) + ":" + IntToStr(localCalendar.get(13), 2) + " ";
  }

  public static ArrayList<Trafico.DatosTrafico> OrdenaHashTable(Hashtable<Integer, Trafico.DatosTrafico> paramHashtable)
  {
    ArrayList localArrayList = new ArrayList();
    Enumeration localEnumeration = paramHashtable.keys();
    Trafico.DatosTrafico localDatosTrafico;
    for (;;)
    {
      if (!localEnumeration.hasMoreElements()) {
        return localArrayList;
      }
      localDatosTrafico = (Trafico.DatosTrafico)paramHashtable.get((Integer)localEnumeration.nextElement());
      if (localDatosTrafico.total.longValue() > 0L)
      {
        if (!localArrayList.isEmpty()) {
          break;
        }
        localArrayList.add(localDatosTrafico);
      }
    }
    label139:
    label141:
    for (int i = 0;; i++)
    {
      int j = localArrayList.size();
      int k = 0;
      if (i >= j) {}
      for (;;)
      {
        if (k != 0) {
          break label139;
        }
        localArrayList.add(localDatosTrafico);
       // break;
        if (localDatosTrafico.total.longValue() <= ((Trafico.DatosTrafico)localArrayList.get(i)).total.longValue()) {
          break;
        }
        localArrayList.add(i, localDatosTrafico);
        k = 1;
      }
      break;
    }
      return null;
  }

  public static int Relativo1000000(int paramInt1, int paramInt2)
  {
    return Double.valueOf(Double.valueOf(ValorMaximoRelativo / paramInt1).doubleValue() * paramInt2).intValue();
  }

  private boolean SDDisponible()
  {
    String str = Environment.getExternalStorageState();
    int j = 0;
    int i = 0;
    if (str.equals("mounted"))
    {
      j = 1;
      i = 1;
    }
    while ((j != 0) && (i != 0))
    {
     // return true;
      if (str.equals("mounted_ro"))
      {
        j = 1;
        i = 0;
      }
      else
      {
        i = 0;
        j = 0;
      }
    }
    return false;
  }

  private TextView SetStyle(TextView paramTextView, boolean paramBoolean)
  {
    paramTextView.setPadding(2, 1, 5, 1);
    if (paramBoolean) {
      paramTextView.setGravity(5);
    }
    paramTextView.setTextColor(-16777216);
    paramTextView.setBackgroundResource(2130968576);
    return paramTextView;
  }

  /* Error */
  private void WriteSettings(Context paramContext, String paramString1, String paramString2)
  {
    // Byte code:
    //   0: aload_2
    //   1: invokevirtual 280	java/lang/String:trim	()Ljava/lang/String;
    //   4: astore 4
    //   6: aconst_null
    //   7: astore 5
    //   9: aconst_null
    //   10: astore 6
    //   12: aload_1
    //   13: aload_3
    //   14: iconst_0
    //   15: invokevirtual 284	android/content/Context:openFileOutput	(Ljava/lang/String;I)Ljava/io/FileOutputStream;
    //   18: astore 5
    //   20: new 286	java/io/OutputStreamWriter
    //   23: dup
    //   24: aload 5
    //   26: invokespecial 289	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;)V
    //   29: astore 11
    //   31: aload 11
    //   33: aload 4
    //   35: invokevirtual 292	java/io/OutputStreamWriter:append	(Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   38: pop
    //   39: aload 11
    //   41: invokevirtual 295	java/io/OutputStreamWriter:flush	()V
    //   44: aload 11
    //   46: invokevirtual 298	java/io/OutputStreamWriter:close	()V
    //   49: aload 5
    //   51: invokevirtual 301	java/io/FileOutputStream:close	()V
    //   54: return
    //   55: astore 9
    //   57: aload 9
    //   59: invokevirtual 304	java/lang/Exception:printStackTrace	()V
    //   62: aload 6
    //   64: invokevirtual 298	java/io/OutputStreamWriter:close	()V
    //   67: aload 5
    //   69: invokevirtual 301	java/io/FileOutputStream:close	()V
    //   72: return
    //   73: astore 10
    //   75: aload 10
    //   77: invokevirtual 305	java/io/IOException:printStackTrace	()V
    //   80: return
    //   81: astore 7
    //   83: aload 6
    //   85: invokevirtual 298	java/io/OutputStreamWriter:close	()V
    //   88: aload 5
    //   90: invokevirtual 301	java/io/FileOutputStream:close	()V
    //   93: aload 7
    //   95: athrow
    //   96: astore 8
    //   98: aload 8
    //   100: invokevirtual 305	java/io/IOException:printStackTrace	()V
    //   103: goto -10 -> 93
    //   106: astore 13
    //   108: aload 13
    //   110: invokevirtual 305	java/io/IOException:printStackTrace	()V
    //   113: return
    //   114: astore 7
    //   116: aload 11
    //   118: astore 6
    //   120: goto -37 -> 83
    //   123: astore 9
    //   125: aload 11
    //   127: astore 6
    //   129: goto -72 -> 57
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	132	0	this	Util
    //   0	132	1	paramContext	Context
    //   0	132	2	paramString1	String
    //   0	132	3	paramString2	String
    //   4	30	4	str	String
    //   7	82	5	localFileOutputStream	java.io.FileOutputStream
    //   10	118	6	localObject1	Object
    //   81	13	7	localObject2	Object
    //   114	1	7	localObject3	Object
    //   96	3	8	localIOException1	java.io.IOException
    //   55	3	9	localException1	Exception
    //   123	1	9	localException2	Exception
    //   73	3	10	localIOException2	java.io.IOException
    //   29	97	11	localOutputStreamWriter	java.io.OutputStreamWriter
    //   106	3	13	localIOException3	java.io.IOException
    // Exception table:
    //   from	to	target	type
    //   12	31	55	java/lang/Exception
    //   62	72	73	java/io/IOException
    //   12	31	81	finally
    //   57	62	81	finally
    //   83	93	96	java/io/IOException
    //   44	54	106	java/io/IOException
    //   31	44	114	finally
    //   31	44	123	java/lang/Exception
  }

  /* Error */
  private void WriteSettingsSD(String paramString1, String paramString2)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: new 309	java/io/File
    //   5: dup
    //   6: invokestatic 313	android/os/Environment:getExternalStorageDirectory	()Ljava/io/File;
    //   9: invokevirtual 316	java/io/File:getAbsolutePath	()Ljava/lang/String;
    //   12: aload_2
    //   13: invokespecial 318	java/io/File:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   16: astore 4
    //   18: aload 4
    //   20: invokevirtual 321	java/io/File:exists	()Z
    //   23: istore 9
    //   25: aconst_null
    //   26: astore_3
    //   27: iload 9
    //   29: ifeq +44 -> 73
    //   32: new 300	java/io/FileOutputStream
    //   35: dup
    //   36: aload 4
    //   38: iconst_1
    //   39: invokespecial 324	java/io/FileOutputStream:<init>	(Ljava/io/File;Z)V
    //   42: astore 10
    //   44: new 286	java/io/OutputStreamWriter
    //   47: dup
    //   48: aload 10
    //   50: invokespecial 289	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;)V
    //   53: astore 11
    //   55: aload 11
    //   57: aload_1
    //   58: invokevirtual 292	java/io/OutputStreamWriter:append	(Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   61: pop
    //   62: aload 11
    //   64: invokevirtual 298	java/io/OutputStreamWriter:close	()V
    //   67: aload 11
    //   69: invokevirtual 298	java/io/OutputStreamWriter:close	()V
    //   72: return
    //   73: new 300	java/io/FileOutputStream
    //   76: dup
    //   77: aload 4
    //   79: invokespecial 327	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   82: astore 14
    //   84: aload 14
    //   86: astore 10
    //   88: goto -44 -> 44
    //   91: astore 7
    //   93: aload 7
    //   95: invokevirtual 304	java/lang/Exception:printStackTrace	()V
    //   98: aload_3
    //   99: invokevirtual 298	java/io/OutputStreamWriter:close	()V
    //   102: return
    //   103: astore 8
    //   105: aload 8
    //   107: invokevirtual 305	java/io/IOException:printStackTrace	()V
    //   110: return
    //   111: astore 5
    //   113: aload_3
    //   114: invokevirtual 298	java/io/OutputStreamWriter:close	()V
    //   117: aload 5
    //   119: athrow
    //   120: astore 6
    //   122: aload 6
    //   124: invokevirtual 305	java/io/IOException:printStackTrace	()V
    //   127: goto -10 -> 117
    //   130: astore 13
    //   132: aload 13
    //   134: invokevirtual 305	java/io/IOException:printStackTrace	()V
    //   137: return
    //   138: astore 5
    //   140: aload 11
    //   142: astore_3
    //   143: goto -30 -> 113
    //   146: astore 7
    //   148: aload 11
    //   150: astore_3
    //   151: goto -58 -> 93
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	154	0	this	Util
    //   0	154	1	paramString1	String
    //   0	154	2	paramString2	String
    //   1	150	3	localObject1	Object
    //   16	62	4	localFile	java.io.File
    //   111	7	5	localObject2	Object
    //   138	1	5	localObject3	Object
    //   120	3	6	localIOException1	java.io.IOException
    //   91	3	7	localException1	Exception
    //   146	1	7	localException2	Exception
    //   103	3	8	localIOException2	java.io.IOException
    //   23	5	9	bool	boolean
    //   42	45	10	localObject4	Object
    //   53	96	11	localOutputStreamWriter	java.io.OutputStreamWriter
    //   130	3	13	localIOException3	java.io.IOException
    //   82	3	14	localFileOutputStream	java.io.FileOutputStream
    // Exception table:
    //   from	to	target	type
    //   2	25	91	java/lang/Exception
    //   32	44	91	java/lang/Exception
    //   44	55	91	java/lang/Exception
    //   73	84	91	java/lang/Exception
    //   98	102	103	java/io/IOException
    //   2	25	111	finally
    //   32	44	111	finally
    //   44	55	111	finally
    //   73	84	111	finally
    //   93	98	111	finally
    //   113	117	120	java/io/IOException
    //   67	72	130	java/io/IOException
    //   55	67	138	finally
    //   55	67	146	java/lang/Exception
  }

  public static void WriteXivato(String paramString)
  {
    temps2 = Calendar.getInstance().getTimeInMillis();
    new Util().WriteLog(paramString + ": " + temps2 + " dif: " + (temps2 - temps1));
    temps1 = temps2;
  }

  public String ArrayToStringCorto(ArrayList<Trafico.DatosTrafico> paramArrayList, Integer paramInteger)
  {
    String str = "";
    int i = 0;
    Iterator localIterator = paramArrayList.iterator();
    for (;;)
    {
      if (!localIterator.hasNext()) {}
      Trafico.DatosTrafico localDatosTrafico;
      do
      {
        //return str;
        localDatosTrafico = (Trafico.DatosTrafico)localIterator.next();
      } while (i >= paramInteger.intValue());
      i++;
      String[] arrayOfString = localDatosTrafico.name.split("#");
      str = str + " " + arrayOfString[0] + " = " + ByteToMega(Double.valueOf(localDatosTrafico.total.longValue())) + " Mb\n";
    }
  }

  public String[] ArrayToStringCortoParaExpandible(ArrayList<Trafico.DatosTrafico> paramArrayList, Integer paramInteger)
  {
   // ((String[])null);
    String[] arrayOfString1 = new String[0];
    int i = 0;
    Iterator localIterator = null;
    if (paramArrayList.size() < paramInteger.intValue())
    {
      arrayOfString1 = new String[paramArrayList.size()];
      i = -1;
      localIterator = paramArrayList.iterator();
    }
    for (;;)
    {
      if (!localIterator.hasNext()) {}
      Trafico.DatosTrafico localDatosTrafico = null;
      do
      {
        //return arrayOfString1;
        arrayOfString1 = new String[paramInteger.intValue()];
        //break;
        localDatosTrafico = (Trafico.DatosTrafico)localIterator.next();
      } while (i >= -1 + paramInteger.intValue());
      i++;
      String[] arrayOfString2 = localDatosTrafico.name.split("#");
      arrayOfString1[i] = ("\t" + arrayOfString2[0] + " = " + ByteToMega(Double.valueOf(localDatosTrafico.total.longValue())) + " Mb (" + ByteToMega(Double.valueOf(localDatosTrafico.rx.longValue())) + "/" + ByteToMega(Double.valueOf(localDatosTrafico.tx.longValue())) + ")");
    }
  }

  public String ArrayToStringLargo(ArrayList<Trafico.DatosTrafico> paramArrayList, Integer paramInteger, Context paramContext)
  {
    String str1 = "";
    String str2 = "";
    int i = 0;
    Iterator localIterator = paramArrayList.iterator();
    if (!localIterator.hasNext()) {}
    Trafico.DatosTrafico localDatosTrafico;
    do
    {
      String str5 = paramContext.getResources().getString(2131165331);
      String str6 = paramContext.getResources().getString(2131165332);
      //return "\n" + str5 + "\n\n" + str1 + str6 + "\n\n" + str2;
      localDatosTrafico = (Trafico.DatosTrafico)localIterator.next();
    } while (i >= paramInteger.intValue());
    i++;
    String[] arrayOfString = localDatosTrafico.name.split("#");
    if (localDatosTrafico.uid < 10000)
    {
      int m = arrayOfString.length;
      for (int n = 0;; n++)
      {
        if (n >= m)
        {
          str2 = str2 + "Total: " + ByteToMega(Double.valueOf(localDatosTrafico.total.longValue())) + " Mb (" + ByteToMega(Double.valueOf(localDatosTrafico.rx.longValue())) + "/" + ByteToMega(Double.valueOf(localDatosTrafico.tx.longValue())) + ")\n\n";
          break;
        }
        String str4 = arrayOfString[n];
        str2 = str2 + ">" + str4 + "\n";
      }
    }
    int j = arrayOfString.length;
    for (int k = 0;; k++)
    {
      if (k >= j)
      {
        str1 = str1 + "Total: " + ByteToMega(Double.valueOf(localDatosTrafico.total.longValue())) + " Mb (" + ByteToMega(Double.valueOf(localDatosTrafico.rx.longValue())) + "/" + ByteToMega(Double.valueOf(localDatosTrafico.tx.longValue())) + ")\n\n";
        break;
      }
      String str3 = arrayOfString[k];
      str1 = str1 + ">" + str3 + "\n";
    }
      return str1;
  }

  public void ArrayToTableLayoutCorto(ArrayList<Trafico.DatosTrafico> paramArrayList, Integer paramInteger, TableLayout paramTableLayout, Context paramContext)
  {
    paramTableLayout.removeAllViews();
    int i = 0;
    Iterator localIterator = paramArrayList.iterator();
    for (;;)
    {
      if (!localIterator.hasNext()) {}
      Trafico.DatosTrafico localDatosTrafico;
      do
      {
        //return;
        localDatosTrafico = (Trafico.DatosTrafico)localIterator.next();
      } while (i >= paramInteger.intValue());
      i++;
      String[] arrayOfString = localDatosTrafico.name.split("#");
      TextView localTextView1 = new TextView(paramContext);
      TextView localTextView2 = new TextView(paramContext);
      localTextView1.setText(" " + arrayOfString[0] + " ");
      localTextView2.setText(ByteToMega(Double.valueOf(localDatosTrafico.total.longValue())) + " Mb");
      TextView localTextView3 = SetStyle(localTextView1, false);
      TextView localTextView4 = SetStyle(localTextView2, true);
      TableRow localTableRow = new TableRow(paramContext);
      localTableRow.addView(localTextView3);
      localTableRow.addView(localTextView4);
      paramTableLayout.addView(localTableRow);
    }
  }

  public void WriteLog(Context paramContext, String paramString)
  {
    String str = NowTimeToString() + paramString;
    if (SDDisponible())
    {
      WriteSettingsSD(str, ConsumoDatosInternetActivity.nomFitxer);
      return;
    }
    WriteSettings(paramContext, str, ConsumoDatosInternetActivity.nomFitxer);
  }

  public void WriteLog(String paramString)
  {
    String str = NowTimeToString() + paramString;
    if (SDDisponible()) {
      WriteSettingsSD(str, ConsumoDatosInternetActivity.nomFitxer);
    }
  }

  public void WriteLog(String paramString1, String paramString2)
  {
    String str = NowTimeToString() + paramString1;
    if (SDDisponible()) {
      WriteSettingsSD(str, paramString2);
    }
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */