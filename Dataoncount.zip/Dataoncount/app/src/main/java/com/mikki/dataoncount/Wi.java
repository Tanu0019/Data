package com.mikki.dataoncount;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.widget.RemoteViews;
import android.widget.Toast;

public class Wi
  extends AppWidgetProvider
{
  public static String ACTION_WIDGET_CONFIGURE = "ConfigureWidget";
  
  public static void ActualizaBarrasWidget(Context paramContext, AppWidgetManager paramAppWidgetManager, int paramInt, RemoteViews paramRemoteViews)
  {
    CDIBD localCDIBD = null;
    if (0 == 0) {}
    try
    {
      localCDIBD = new CDIBD(paramContext, null, ConsumoDatosInternetActivity.versionBD);
      SQLiteDatabase localSQLiteDatabase = localCDIBD.AbreBD();
      Configuracion localConfiguracion = new Configuracion();
      localConfiguracion.CargaConfiguracion(localSQLiteDatabase, paramContext);
      ConsumoDatosInternetActivity.ActualizaBarras(true, paramRemoteViews, 2131230837, 2131230838, 2131230839, 2131230840, localConfiguracion, paramContext, localSQLiteDatabase);
      localCDIBD.CierraBD(localSQLiteDatabase);
      paramAppWidgetManager.updateAppWidget(paramInt, paramRemoteViews);
      return;
    }
    catch (Exception localException)
    {
      new Util().WriteLog(paramContext, "Error 5498: " + localException.getMessage());
      Toast.makeText(paramContext, "Error al actualizar", 1).show();
    }
  }
  
  public void onUpdate(Context paramContext, AppWidgetManager paramAppWidgetManager, int[] paramArrayOfInt)
  {
    for (int i = 0;; i++)
    {
      if (i >= paramArrayOfInt.length) {
        return;
      }
      int j = paramArrayOfInt[i];
      Intent localIntent = new Intent(paramContext, ConsumoDatosInternetActivity.class);
      localIntent.setFlags(268435456);
      PendingIntent localPendingIntent = PendingIntent.getActivity(paramContext, 0, localIntent, 134217728);
      RemoteViews localRemoteViews = new RemoteViews(paramContext.getPackageName(), 2130903053);
      localRemoteViews.setOnClickPendingIntent(2131230838, localPendingIntent);
      localRemoteViews.setOnClickPendingIntent(2131230840, localPendingIntent);
      localRemoteViews.setOnClickPendingIntent(2131230837, localPendingIntent);
      localRemoteViews.setOnClickPendingIntent(2131230839, localPendingIntent);
      ActualizaBarrasWidget(paramContext, paramAppWidgetManager, j, localRemoteViews);
    }
  }
}


/* Location:              C:\Users\mikki\Desktop\classes_dex2jar.jar!\com\si\datausage\Wi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */